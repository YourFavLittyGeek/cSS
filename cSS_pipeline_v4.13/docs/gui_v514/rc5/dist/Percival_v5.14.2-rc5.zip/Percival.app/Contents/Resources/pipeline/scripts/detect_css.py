#!/usr/bin/env python3
"""cSS candidate detector v4 (v4.17) - definition-driven.
usage: detect_css.py SUBJECT [z_thr=-2.5] [ridge_pct=85] [rim_mm=3]
env:   CSS_RANK=v3 ranks with the old v3 score (both scores are always written)
       CSS_USE_MIMIC=1 (v5.0) mimic layer acts: score x0.5 with FLAIR evidence, exclusions E10 / E11 (see below)
       CSS_QC_STRICT=1 (v5.0) case QC insufficient_quality -> header-only candidates CSV, exit 3
       Both unset (default) = v4.19 candidates, exclusions and order; the new columns are written either way.
v5.0 Layer 1 (mimic_rules.py), columns appended to candidates and excluded: mimic_score, mimic_class, mimic_reason,
  phase_z, mb_cluster_n, phase_r. Phase (data/ID_phase.nii.gz, same grid, newer than the SWI): the dipole pattern of
  the candidate's own shape is fitted to the 4 mm high-pass phase (orientation-aware; the scanner sign is fitted on
  the vessel map) -> phase_z < 0 = diamagnetic (calcification). E10@v5.0: calcification, mimic_score >= 0.7.
  E11@v5.0: >= 3 compact parenchymal blobs (microbleed cluster), mimic_score >= 0.5. FLAIR (acute cSAH / cortical
  vein thrombosis) is a soft penalty only. Laminar necrosis / haemorrhagic infarct are not handled (no DWI / T1 sign).
  Deprecated, still computed for regression integrity (to be NaN in v5.1): vein_tree_mm, mirror_dark_frac,
  branch_per10mm.

cSS (STRIVE-2 / Charidimou): curvilinear hypointensity in the SUBPIAL cortex / subarachnoid
space that follows the gyral surface, often on both banks of a sulcus ("tram-track"),
supratentorial, remote from lobar ICH, no FLAIR hyperintensity (that would be acute cSAH).
Each criterion is measured per candidate:

  definition                      column(s)                      cSS            vein / mimic
  outlines the cortical surface   pial_dist_mm, bank_frac        ~0 mm, high    sulcal centre (>0)
  curvilinear sheet, not a tube   tube_ratio (3-D Hessian)       low (plate)    high (tube)
  follows the gyral contour       surface_alignment              high (~1)      lower
  tram-track (both banks)         tram_frac                      >0             ~0
  not part of the venous tree     vein_tree_mm (recorded only)   short          long network
  asymmetric                      mirror_dark_frac               low            high (normal veins)
  stays on the surface (v4.11)    vessel_wm_mm (tube continues   ~0             medullary / transcortical
                                  into the WM), vessel_ext_mm                   vein: several mm
  runs along the cortex (v4.11)   axis_normal (long axis . normal) low          high (penetrating vessel,
                                                                                vein down a sulcus)
  remote from ICH                 ich_dist_mm, near_ich_suggest  far            <=5 mm
  supratentorial, not basal       infra_frac, basal_frac,        ~0             cerebellum/tentorium,
                                  rel_height                                    basal cisterns, skull base
  supratentorial                  infratentorial                 0              1 (classical SS)
  chronic, not acute cSAH         flair_csf_z, flair_bright      FLAIR not bright (hint only:
                                                                 chronic cSS can show mild FLAIR signal)
  mimic: cortical vein thrombosis flair_ctx_z, flair_ctx_bright  FLAIR-bright cortex nearby -> check
  not a microbleed (AJNR 2016)    parenchyma_frac, extent_mm,    surface/CSF     <=10 mm and >=half
                                  cmb_like                                       in parenchyma
                                  (only if work/ID_flair_swispace.nii.gz exists)

Candidate generation (unchanged idea from v3, tightened):
  - search zone = pial band: cortex + subarachnoid CSF, -3.5..+4 mm from the pial surface, minus
    white matter / deep nuclei (v3 dilated cortex into WM, which is darker than GM on SWI)
  - darkness z vs a LOCAL cortex reference that now EXCLUDES locally dark voxels (2-pass), so
    extensive cSS no longer darkens its own reference
  - 2-D Sato ridge + hysteresis, per hemisphere; >=25 mm3, >=2 slices, elongation >=2.0
Labels: work/ID_seg_swispace.nii.gz (from T1 via prep_anat.sh when available, else SWI SynthSeg).
Lobar ICH mask: work/ID_ich.nii.gz if you drew one (freeview), else found automatically.
v4.14 bookkeeping (no change to which candidates are shown or excluded, except B1 below):
  review/ID_qc.json        case QC (css_qc.py): protocol, orientation, coverage, anatomy, pial-edge agreement,
                           status ok / low_confidence_review / insufficient_quality (reported only)
  work/ID_dropped.csv/.nii.gz  components removed by the generation gates (size, slices, elongation, no
                           cortex nearby) - before v4.14 they vanished without a record
  new columns (appended): candidates qc_status, rule_version, n_pieces; excluded also exclusion_confidence
  B1 fix: extent_mm was underestimated for candidates touching the first array slice/row/column
v4.17 (audit Stage 2): sulcal CSF = brain voxels outside the labelled tissue (recon-all aparc+aseg leaves sulcal CSF
  as label 0; label 24 alone missed it -> surface_contact and the FLAIR CSF reference were wrong on that route);
  3-D Hessian on the mask-filled image (zeros outside the mask made edge curvature); E8 artifact-zone rule needs
  T1 anatomy like E2/E3; a FLAIR older than the SWI is ignored; work/ID_gen.nii.gz records per voxel which
  generation stage it passed (label_missed.py uses it); review/ID_manifest.json records inputs (sha256),
  versions and environment.
v4.16: bounded local vein tracking columns (css_vessel.py; recorded only - no rule or score uses them):
  cand_geodesic_mm, local_cont_max/min/total_mm, terminal_ends, local_net_mm, local_branch_points/_per10mm
"""
import signal; signal.signal(signal.SIGPIPE, signal.SIG_DFL)   # quiet when piped to head
import sys, os, json, numpy as np, nibabel as nib, pandas as pd
from scipy import ndimage as ndi
from skimage.filters import sato
from skimage.measure import regionprops
from skimage.morphology import skeletonize
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from css_common import match_calls, base as _base, load_lut, fresh, sha256, update_manifest, environment_record, skeleton_length, radius_profile
import css_shape, css_confidence
import css_qc, css_vessel, mimic_rules, css_pieces, css_features, css_tiers, css_sheet3d

subj   = sys.argv[1]
z_thr  = float(sys.argv[2]) if len(sys.argv) > 2 else -2.5
r_pct  = float(sys.argv[3]) if len(sys.argv) > 3 else 85
RIM_MM = float(sys.argv[4]) if len(sys.argv) > 4 else 3.0
RANK   = os.environ.get("CSS_RANK", "v4")
RULESET = "v4.18"                        # written to every row as rule_version
Z_LOW, R_PCT_LOW = -2.0, 80           # hysteresis (weak) thresholds
GROW_Z = -1.5                          # 'dark' map used for region growing at scoring
MIN_MM3, MIN_SLICES, MIN_ELONG = 25.0, 2, 2.0   # v4: 2.0 (tram-track = two parallel plates, ~2.4;
                                                # round microbleeds stay ~1-1.5)
PIAL_IN_MM, PIAL_OUT_MM = 3.5, 4.0     # pial band: cortex thickness + blooming / subarachnoid CSF
# v4.8 false-positive reduction (reader feedback on P006: duplicates, specks, obvious veins, skull-base
# artifact, faint normal cortex). v4.9.2: microbleed-like is a flag only; skull-base / basal rules need T1
# anatomy and a scan that includes the skull base. Excluded candidates are NOT deleted: they are listed with the reason
# in review/ID_excluded.csv (+ .nii.gz). CSS_KEEP_ALL=1 switches all exclusions off.
# v4.18: 2-D ridge (Sato) scales in mm, not pixels. [1, 2, 3] px were 0.47-1.4 mm on P010 (0.47 mm) but
# 0.86-2.6 mm on P011 (0.86 mm); these values reproduce the validated P006 behaviour (0.573 mm -> 1.05/2.09/3.14 px)
SATO_SIGMAS_MM = (0.6, 1.2, 1.8)
MERGE_GAP_MM = 3.0      # fragments of one dark line closer than this are merged into one candidate
MERGE_MAX_MM = 40.0     # ...but only while the merged object stays focus-sized: on P006 unlimited merging
                        # chained veins along a whole hemisphere into 10-17 cm objects (v4.9.1)
MIN_EXTENT_MM = 6.0     # specks: smaller than this overall are not curvilinear cSS
MIN_EDGE_SD = 0.75      # "well-defined": candidate must be darker than its 1-2 mm surroundings by this
KEEP_ALL = os.environ.get("CSS_KEEP_ALL", "") == "1"
# v5.0 opt-in layers (default off = v4.19 behaviour; the new columns are written either way):
#   CSS_USE_MIMIC=1  mimic layer acts: score x0.5 with FLAIR evidence, exclusions E10 (calcification) / E11 (MB cluster)
#   CSS_QC_STRICT=1  case QC gates: insufficient_quality -> no candidates, exit 3
USE_MIMIC = os.environ.get("CSS_USE_MIMIC", "") == "1"
QC_STRICT = os.environ.get("CSS_QC_STRICT", "") == "1"
#   CSS_MIXED_REVIEW=1 (v5.1.1) a merged object whose pieces disagree (vein-like + cSS-like) is not excluded by the
#   vein rules E5 / E6 / E7 as a whole; it is shown with mixed_object_review = 1
MIXED_REVIEW = os.environ.get("CSS_MIXED_REVIEW", "") == "1"
#   CSS_V53=1 (v5.3.1, from the M02-M11 reading; NOT validated - thresholds were chosen on those 10 patients):
#   needs T1 anatomy. (a) candidates are generated exactly as without the switch (same zone, same ridge percentiles);
#   then object voxels more than V53_OUT_MM outside the labelled pial boundary are removed (dark inner skull / dura
#   inside the grown brain mask). v5.3.0 narrowed the search zone itself: that shifted the ridge percentiles and cut
#   the hysteresis seeds, and lost 3 reader-called cSS at generation. (b) exclusions E12 extent (volume only),
#   E13 midline (falx / sinus in the interhemispheric fissure), E14 orbitofrontal air-bone zone, E15 skull band
#   (only for objects lying on / outside the brain surface), E16 ventricles; E1 infratentorial is unchanged and always
#   on. (c) second merge pass: objects within V53_GAP_MM AND with the same cortical region label join (v5.3.0 joined
#   any objects within 6 mm: 10 joined a reader-called cSS with a vein / normal / artifact). Without the switch the
#   columns below are still recorded and nothing else changes.
# ======================================================================================================================
# FROZEN RULE SET (branch fix/audit-v5.7-priority1, from the independent audit, finding F3):
# every threshold below that was fitted on M02-M11 (E12 ... E25, the generation gates and the second merge pass) was set on 10 patients read by ONE
# non-expert reader (repeat-read kappa 0.65 with the AI meter visible, 0.87 hidden). They are FROZEN: do not tighten or add a threshold on the
# development set. New rules may be added only as opt-in switches, with the margin to the nearest called cSS reported, and are then judged ONCE on
# the held-out cases (M12-M15, M01) with adjudicated labels. The thresholds and the active switches are written to review/ID_manifest.json
# (detect > parameters > frozen_rules / switches) on every run.
# ======================================================================================================================
V53 = os.environ.get("CSS_V53", "") == "1"
# CSS_SOFT_GATES=1 (audit F4, opt-in, default OFF = unchanged output): an object that fails a GENERATION gate (G1 volume, G2 slices, G3 elongation)
# is not dropped but shown as the LAST candidates with soft_gate_fail = the gate id, review priority tier 4 and a note; it is listed in
# work/ID_soft_gate.csv (measured value and threshold) instead of ID_dropped.csv (an object has exactly one fate). Objects with < 5 voxels and G4 (no
# cortex label within 2 voxels) stay hard drops.
SOFT_GATES = os.environ.get("CSS_SOFT_GATES", "") == "1"
# CSS_3D_SEEDS=1 (audit F2, opt-in, default OFF; RECORDED ONLY): a second, orientation-free seed source next to the per-slice 2-D ridge. A 3-D plate-ness (dark
# sheet) filter on the same image, the same zone, the same darkness thresholds and the same hysteresis percentiles gives work/ID_gen_3d.nii.gz and
# work/ID_3d_only.csv (3-D objects that touch no 2-D object); nothing shown or excluded changes. A union with the 2-D seeds is NOT implemented: it needs
# the overlap statistics (manifest: detect > seeds3d) judged first.
SEEDS3D = os.environ.get("CSS_3D_SEEDS", "") == "1"
# CSS_E22_PIECES=1 (opt-in, default OFF): E22 (midline sheet) is judged on the FIRST-PASS pieces of an object (as E12 is) instead of the merged object: the
# object is a midline sheet only if one of its first-pass pieces is one (all three E22 conditions on that piece). Reason: the second merge pass (5 mm, same
# region) can join a short cSS piece with its neighbours into one object that then looks like a long sheet (M11 #12: 15 mm piece -> 29.5 mm merged object).
# No new threshold. The columns piece_sheet / ext_piece_max_mm are always recorded.
# v5.8 (plan docs/PLAN_v5.8_search_zone.md) compartments, RECORDED always; E26 / E27 exclude only with CSS_ZONE2=1 (opt-in, default OFF, needs CSS_V53=1)
#   zone2_frac   share of the object in RIBBON (labelled cortex) or SULCAL CSF (inside the 4 mm morphological closing of ONE hemisphere's cortex, not in
#                the fissure) -> low = convexity CSF / dura / skull or fissure;  E26: zone2_frac < ZONE2_FRAC
#   sylvian_frac share within 3 mm of insula AND of opercular cortex (frontal / parietal operculum, superior temporal) -> Sylvian vessels; E27: >= SYLV_FRAC
ZONE2 = os.environ.get("CSS_ZONE2", "") == "1"
ZONE2_R_MM, ZONE2_FRAC = 4.0, float(os.environ.get("CSS_ZONE2_FRAC", "0"))   # v5.8.1: E26 OFF (M02-M11: lost M04 #28 at 0.42, gained <= 1 non-cSS)
SYLV_MM, SYLV_FRAC = 3.0, float(os.environ.get("CSS_SYLV_FRAC", "0.2"))   # v5.8.4: was 0.4. cSS max 0.09 on M02-M11 (ST / ML protected: 0.00); 6 more shown non-cSS
# v5.9 3-D structure (css_shape.struct_measures): the whole dark structure of every object is measured (ball / tube / ribbon, cortex share, runs along the surface or
# leaves it, continues beyond the object). Columns struct_* are ALWAYS recorded. E28 excludes only with CSS_STRUCT=1 (opt-in, default OFF; thresholds provisional until
# struct_probe.py has fitted them on M02-M11 against protected cSS): a compact BALL with at most STRUCT_BALL_CTX of it in cortex, or a TUBE that continues
# STRUCT_TUBE_CONT times beyond the object and leaves the surface (|cos| >= STRUCT_TUBE_COS).
STRUCT = os.environ.get("CSS_STRUCT", "") == "1"
STRUCT_BALL_CTX, STRUCT_TUBE_CONT, STRUCT_TUBE_COS = float(os.environ.get("CSS_STRUCT_BALL_CTX", "0.3")), float(os.environ.get("CSS_STRUCT_TUBE_CONT", "3.0")), float(os.environ.get("CSS_STRUCT_TUBE_COS", "0.5"))
# v5.10 confidence model (css_confidence.py; fitted by fit_confidence.py -> review/confidence_model.json). When the file exists every object gets confidence_pct
# (0-100, NOT a validated probability) and confidence_why. CSS_CONF=1 (opt-in): an object the other rules keep is excluded as E30 when its confidence is below
# the model's own cut (set by the fit below the lowest protected cSS, with a margin). No model file -> columns empty, nothing excluded.
# Phase 1 (safety) G2 slice gate in millimetres. The gate was "at least MIN_SLICES (2) slices", set on 1.2 mm slices = 2.4 mm of through-plane extent. On
# 3 mm slices that silently became "at least 6 mm", so a focus visible on ONE 3 mm slice was dropped whatever its in-plane length. Now an object passes G2 when
# it spans >= MIN_SLICES slices OR its through-plane extent (slices x slice thickness) is >= MIN_SI_MM. Scans with slices < 2.4 mm behave exactly as before.
# Objects that pass only through the mm criterion are marked single_slice = 1 (recorded). CSS_SLICE_GATE=legacy restores the slice-count gate.
MIN_SI_MM = 2.4
SLICE_GATE_LEGACY = os.environ.get("CSS_SLICE_GATE", "") == "legacy"
def passes_slice_gate(n_sl, vz):
    return n_sl >= MIN_SLICES or (not SLICE_GATE_LEGACY and n_sl >= 1 and n_sl * float(vz) >= MIN_SI_MM)
# Phase 1 (safety) registration gate. With T1 anatomy every anatomical rule and the sulcal score rest on the T1 labels lying on the SWI. css_qc measures the
# label shift against the SWI cortex edge; when it exceeds css_qc.EDGE_LOW_CONF_MM (1.5 mm, the existing limit) the registration is NOT acceptable: the
# detector stops with exit code 5 BEFORE writing any list (existing lists, calls and fates stay untouched) and review/ID_qc.json says registration_ok = false.
# CSS_ALLOW_BAD_REG=1 lets it continue (lists are then written with qc_status low_confidence_review, as before this change).
ALLOW_BAD_REG = os.environ.get("CSS_ALLOW_BAD_REG", "") == "1"
# Phase 1 (safety) confidence exclusion. E30 is applied only when the model's cut was set from leave-one-patient-out predictions (cut_method "lopo_min"), i.e.
# from patients the model had not seen. A cut taken from the model's own training patients ("insample_min"), a hand-set cut ("manual") or a model file without
# cut_method is NOT applied unless CSS_CONF_ALLOW_OPTIMISTIC=1; confidence_pct is still recorded. The role of the study for the model (development = one of
# the fit studies, evaluation = any other) is written to the manifest.
CONF_ALLOW_OPTIMISTIC = os.environ.get("CSS_CONF_ALLOW_OPTIMISTIC", "") == "1"
CONF = os.environ.get("CSS_CONF", "") == "1"
# v5.10.5 side guard: the confidence rule alone may never empty a hemisphere. When every object it removes on one side was the last shown object there, the
# highest-confidence one of them is kept (conf_guard = 1). Only E30 is undone; objects other rules exclude are never brought back. CSS_CONF_GUARD=0 turns it off.
CONF_GUARD = os.environ.get("CSS_CONF_GUARD", "1") != "0"
E22_PIECES = V53 and os.environ.get("CSS_E22_PIECES", "1") != "0"   # v5.7-E-fix3: ON with CSS_V53=1 (acceptance 56/56 incl. M11 #12); CSS_E22_PIECES=0 = merged-object E22 as in fix2
SHEET3D_SIGMAS_MM = (0.6, 1.2, 1.8)
V53_OUT_MM = 1.0                 # E17: voxels further than this outside the labelled pial boundary count as "outside"
E17_FRAC, E17_CTX = 0.6, 0.4         # E17: >= this share outside AND cortex_frac below this (and no tram-track)
# v5.3.3 thresholds set just beyond the most extreme of the 61 reader-called cSS of M02-M11 (min / max in brackets).
# They are fitted to those 10 patients: on new patients some cSS WILL fall outside them - check ID_excluded.csv.
E15_SKULL = 0.70                     # skull band (cSS max 0.64)
E18_EDGE = 1.5                       # ill-defined: edge contrast below this (cSS min 1.72; E9 keeps 0.75 for all)
E19_DARK = 4.5                       # darker than any cSS read (cSS max 4.3) ...
E20_VOL = 1000.0                     # larger than any cSS focus read (cSS max 895 mm3, after merging) ...
E21_CTX = 0.33                       # off the cortex (cSS min 0.38) ...
E19_SKULL = 0.3                      # ... E19 / E20 / E21 only for objects that are also partly skull-backed: darkness,
                                     # size and cortex share depend on the scanner, TE and disease extent (the synthetic
                                     # phantom cSS are darker and larger than any read cSS and must not be excluded)
E13_FRAC_V533 = 0.5                  # midline, any depth (cSS max 0.36)
# v5.3.4 E22 midline sheet (from review/midline_probe on M02-M11: of 55 shown cSS none satisfies all three; 11 non-cSS do):
# v5.7 E24 skull-base cortex zone (from review/zone_probe on M02-M11: 15 shown non-cSS objects flagged, 0 of 67 protected cSS; the
# nearest protected cSS has 0.09 of its voxels nearest to this cortex): an object whose nearest cortex is orbitofrontal / frontal pole /
# temporal pole / entorhinal / pars orbitalis (the air-bone susceptibility surfaces) in >= E24_FRAC of its voxels. Occipital and inferior
# temporal cortex over the tentorium is NOT in the set (kept when the nearest tissue is cerebral cortex). Needs a parcellated T1 labelling.
# v5.7 E25 interhemispheric fissure (zone_probe on M02-M11 with the reader's final decisions: 8 shown non-cSS flagged, 0 of 63 cSS; the
# highest cSS value is 0.17 [M05 #3, pericalcarine] vs threshold 0.3): the object lies BETWEEN the hemispheres - left cortex AND right cortex both
# within E25_REACH_MM of at least E25_FRAC of its voxels (falx, sagittal sinus, pericallosal / fissure vessels; a sulcal cSS has one hemisphere
# on both banks). Objects hugging ONE medial surface are not flagged.
E25_FRAC, E25_REACH_MM = 0.3, 3.0
E24_FRAC = 0.2                       # v5.8.4: was 0.5. M02-M11: no cSS call (52 primary, ST, ML) has ANY skull-base share (max 0.00); 5 more shown non-cSS at >= 0.2
E24_LABELS = [1012, 1014, 1032, 1033, 1006, 1019]       # lateral / medial orbitofrontal, frontal pole, temporal pole, entorhinal, pars orbitalis (+2000 = right)
E24_LABELS = E24_LABELS + [x + 1000 for x in E24_LABELS]
E22_PLANE_MM, E22_COS, E22_EXT_MM = 8.0, 0.9, 25.0   # within 8 mm of the mid-sagittal plane, thin axis aligned with it, >= 25 mm long
V53_GAP_MM, V53_MAX_MM = 5.0, 80.0   # second merge pass: gap (same region label only) and cap on the bounding-box diagonal
E12_MM3 = 3000.0                     # extent: one connected object above this volume (largest reader-called cSS 830 mm3;
                                     # v5.3.0 also used length > 60 mm, which removed 9 thin cSS)
VENT = [4, 5, 14, 15, 43, 44, 31, 63, 72]   # lateral / 3rd / 4th / 5th ventricle, choroid plexus
E16_MM, E16_FRAC = 3.0, 0.3          # ventricles: share of the object within this distance of a ventricle / choroid label
E13_MID_MM, E13_FRAC = 3.0, 0.5      # midline: share of the object within this distance of the hemisphere boundary
E14_EDGE_MM = 8.0                    # orbitofrontal: object this close to the brain-mask edge
E15_FRAC = 0.5                       # skull band: share of the object whose outward 3-6 mm is dark / outside the mask
SKULL_EDGE_MM = 6.0                  # ... counted only this close to the brain-mask edge (not across a sulcus)
PIECE_MIN_FRAC = 0.15        # mixed_object: each kind of piece holds >= this share of the object's volume
MIMIC_CALC_EXCL, MIMIC_MB_EXCL = 0.7, 0.5   # E10 / E11 mimic_score cut-offs (not validated)
HESS_SIGMAS_MM = (0.8, 1.6)            # 3-D shape analysis scales
# v4.11 vessel exclusion: a dark line that continues as a TUBE beyond the cortical band (into the white
# matter = medullary / transcortical vein) and runs perpendicular to the cortex is a vessel, not cSS
VES_WM_MM = 15.0        # how deep under the cortical band the vessel map reaches
MIDLINE_END_MM = 4.0    # v4.18 end_type "midline": continuation reaches within this of the mid-sagittal plane
VES_REACH_MM = 20.0     # vessel continuation is measured up to this distance (bounded: vein_tree saturated)
OFF_CTX_FRAC, OFF_PIAL_MM = 0.30, 0.30   # v4.12 "off the cortex" exclusion (T1 anatomy only)
VES_WM_Z = -3.0         # WM vessel voxels: this many SD darker than the white matter
VES_MIN_MM = 3.0        # vessel pieces shorter than this are noise
VES_CONE_DEG = 30.0     # WM continuation counts only inside this cone, straight on from the candidate
VES_EXCL_WM_MM = 4.0    # exclusion: tube continues >= this far into the WM ...
VES_EXCL_AXIS = 0.5     # ... AND the candidate runs perpendicular to the cortex (|long axis . normal|)
TRAM_MAX_MM = 10.0                     # look for the opposite bank up to this far across a sulcus
ICH_MIN_MM3, ICH_MIN_RADIUS_MM = 500.0, 2.5   # automatic lobar ICH: dark, compact (inscribed
                                               # radius >= 2.5 mm, i.e. not a vein/sheet) blob
ARTIFACT_ZONES = ("orbitofrontal", "entorhinal", "temporalpole", "parahippocampal",
                  "fusiform", "inferiortemporal")
LH = [2, 3, 4, 5, 7, 8, 10, 11, 12, 13, 17, 18, 26, 28]
RH = [41, 42, 43, 44, 46, 47, 49, 50, 51, 52, 53, 54, 58, 60]
WM = [2, 41, 77, 251, 252, 253, 254, 255]
DEEP = [4, 5, 10, 11, 12, 13, 14, 15, 16, 17, 18, 26, 28, 31, 43, 44, 49, 50, 51, 52, 53, 54, 58, 60, 63]
INFRA = [7, 8, 46, 47, 16, 15]
BASAL = [16, 28, 60, 17, 18, 53, 54]   # brainstem, ventral DC, hippocampus, amygdala: basal cisterns
INFRA_MM, BASAL_MM = 5.0, 5.0          # "near" = within this distance of those structures
CSF = [24]

base = _base()
swi = nib.load(f"{base}/data/{subj}_swi.nii")
I   = swi.get_fdata().astype(np.float32)
seg = nib.load(f"{base}/work/{subj}_seg_swispace.nii.gz").get_fdata().astype(np.int32)
vox = tuple(float(v) for v in swi.header.get_zooms()[:3])
# v4.9.2 anatomy confidence: millimetre position rules (skull base, basal cisterns) are only trusted
# with T1-derived labels; SynthSeg on the SWI is too coarse (P010: real-looking lesions excluded)
_t1p = f"{base}/work/{subj}_t1seg_swispace.nii.gz"
# v4.18: the slice-wise ridge filter, slice counts, merge gap and "long structure" assume array axis 2 is the
# superior-inferior / slice axis. Stop instead of running in the wrong plane (CSS_ALLOW_ORIENT=1 overrides).
_si = int(np.argmax(np.abs(swi.affine[2, :3])))
if (_si != 2 or vox[2] < max(vox[0], vox[1]) - 1e-3) and os.environ.get("CSS_ALLOW_ORIENT") != "1":
    os.makedirs(f"{base}/review", exist_ok=True)
    _why = (f"array axis 2 is not the slice / S-I axis (orientation {''.join(nib.aff2axcodes(swi.affine))}, "
            f"voxel {[round(v, 3) for v in vox]})")
    json.dump(dict(subject=subj, status="insufficient_quality", orientation_ok=False, si_axis=_si,
                   orientation="".join(nib.aff2axcodes(swi.affine)), voxel_mm=[round(v, 3) for v in vox],
                   reasons=[_why], stopped=True), open(f"{base}/review/{subj}_qc.json", "w"), indent=2)
    print(f"{subj}: STOPPED - {_why}.\n  Reslice the SWI so the slices are axial (e.g. mri_convert --out_orientation LAS"
          f" after checking the acquisition plane), or set CSS_ALLOW_ORIENT=1 to run anyway (geometry unreliable)."
          f"\n  Earlier outputs in review/ for {subj}, if any, are from a previous run.")
    sys.exit(2)
T1_ANAT = os.path.exists(_t1p) and os.path.getmtime(_t1p) >= os.path.getmtime(f"{base}/data/{subj}_swi.nii")
MERGE_GAP_MM = min(max(MERGE_GAP_MM, 2.0 * vox[2]), 4.0)   # thick slices: inter-slice gaps must not split a line
if V53 and not T1_ANAT:
    print(f"{subj}: CSS_V53=1 needs T1 anatomy (work/{subj}_t1seg_swispace.nii.gz) - v5.3 rules are OFF for this case")
    V53 = False
s2d = np.ones((3, 3, 1), bool); s3 = np.ones((3, 3, 3), bool)
mm2vox = lambda mm: tuple(mm / v for v in vox)

brain  = ndi.binary_fill_holes(I > 0)
cortex = (seg >= 1000) | (seg == 3) | (seg == 42)
it = max(1, int(round(2.0 / vox[0])))
edge_band = brain & ~ndi.binary_erosion(brain, structure=s2d, iterations=it)
# ---- 0. signed distance to the pial surface (mm; <0 inside tissue, >0 in CSF) + normals
tissue = ndi.binary_fill_holes(brain & (seg > 0) & ~np.isin(seg, CSF))    # fills ventricles
# v4.17: CSF = brain voxels that are not labelled tissue. SynthSeg labels extracerebral/sulcal CSF 24, but
# recon-all aparc+aseg leaves sulcal CSF unlabelled (0) and uses 24 for a small basal region only
csf_space = brain & ~tissue
# v5.1.2 feature-spec maps (css_features.py, recorded only): distance into the CSF, near-CSF, depth below the crowns
CSF_DEPTH, NEAR_CSF = css_features.csf_maps(csf_space, vox)
SULC_D = css_features.sulcal_depth_map(tissue, vox)
surface = (~brain) | csf_space
near_surface = ndi.binary_dilation(surface, structure=s2d, iterations=it)
pial_sd = (ndi.distance_transform_edt(~tissue, sampling=vox)
           - ndi.distance_transform_edt(tissue, sampling=vox)).astype(np.float32)
_g = np.gradient(ndi.gaussian_filter(pial_sd, mm2vox(1.0)), *vox)
_gn = np.sqrt(sum(g * g for g in _g)) + 1e-6
normal = [(g / _gn).astype(np.float32) for g in _g]          # points from tissue into CSF
del _g, _gn

# ---- 1. robust normalisation, local cortex reference (2-pass, dark voxels excluded)
hi = np.percentile(I[brain], 99.5)
Ic = np.minimum(I, hi)
c = Ic[cortex & (I > 0)]
mu = float(np.median(c)); sd = float(1.4826 * np.median(np.abs(c - mu)) + 1e-6)
_sig = mm2vox(10.0)
def local_ref(ref):
    w = ndi.gaussian_filter(ref.astype(np.float32), _sig)
    m = ndi.gaussian_filter((Ic * ref).astype(np.float32), _sig)
    return np.where(w > 0.05, m / np.maximum(w, 1e-6), mu)
# v5.10 cSS next to a lobar ICH: a READER-DRAWN haemorrhage (work/ID_ich.nii.gz) and a 4 mm rim around it are left out of the local cortex reference, so the
# haemorrhage no longer drags the reference down and makes neighbouring cSS look less dark. Without a drawn mask nothing changes.
_ichp = f"{base}/work/{subj}_ich.nii.gz"; ICH_REF = None
if os.path.exists(_ichp):
    _im = np.asanyarray(nib.load(_ichp).dataobj) > 0
    if _im.shape == I.shape and _im.any(): ICH_REF = ndi.distance_transform_edt(~_im, sampling=vox) <= 4.0
    del _im
_cref = cortex if ICH_REF is None else (cortex & ~ICH_REF)
z = (Ic - local_ref(_cref)) / sd
# pass 2: locally dark cortex (lesion candidates) no longer pulls its own reference down;
# regionally dark NORMAL cortex (iron-rich motor cortex) is not locally dark, so it stays in
_ref2 = _cref & (z > Z_LOW)
z = (Ic - local_ref(_ref2)) / sd
# v5.1.1: where the pass-2 cortex reference had enough valid voxels (else the global cortex median was used)
REF_OK = ndi.gaussian_filter(_ref2.astype(np.float32), _sig) > 0.05; del _ref2
z_glob = (Ic - mu) / sd
# v4.19.2 regional + contralateral reference (recorded only). LEMON P201 (healthy): 5 of 6 candidates were
# naturally dark cortex (motor strip, cuneus/precuneus: iron/myelin), patch-shaped like cSS. Physiological
# darkness covers much of its anatomical region and is roughly symmetric; cSS is focal and usually one-sided.
_ci = np.nonzero(cortex & brain); _cl = seg[_ci]; _cv = Ic[_ci].astype(np.float32); del _ci
_o = np.argsort(_cl, kind="stable"); _cl, _cv = _cl[_o], _cv[_o]
_u, _st = np.unique(_cl, return_index=True); _en = np.r_[_st[1:], len(_cl)]
REG = {}
for _c, _a, _b in zip(_u, _st, _en):
    _v = np.sort(_cv[_a:_b])
    if len(_v) >= 200:
        _m = float(np.median(_v)); REG[int(_c)] = (_v, _m, float(1.4826 * np.median(np.abs(_v - _m)) + 1e-6))
del _cl, _cv, _o
def mirror_code(c):
    if 1000 <= c < 2000: return c + 1000
    if 2000 <= c < 3000: return c - 1000
    return {3: 42, 42: 3}.get(c, -1)
def region_ref(code, vals_c, own_vals):
    """vals_c: candidate intensities; own_vals: the candidate's voxels that are in its own label's cortex"""
    nan = dict(region_z=np.nan, region_dark_frac=np.nan, mirror_region_z=np.nan, cand_mirror_z=np.nan, region_n_vox=0)
    if code not in REG or not len(vals_c): return nan
    v, m, sd_ = REG[code]; cm_ = float(np.median(vals_c))
    out = dict(nan, region_z=round((cm_ - m) / sd_, 2), region_n_vox=int(len(v)))
    # share of the region's cortex (candidate itself left out) at least half as dark as the candidate, measured
    # from the whole-brain cortex median: high = the region is broadly dark (physiological pattern)
    thr = mu + 0.5 * (cm_ - mu)
    n_all = int(np.searchsorted(v, thr, side="right")) - int((own_vals <= thr).sum())
    n_tot = len(v) - len(own_vals)
    if cm_ < mu and n_tot > 0: out["region_dark_frac"] = round(max(n_all, 0) / n_tot, 3)
    mc = mirror_code(code)
    if mc in REG:
        vm, mm_, sdm = REG[mc]
        out["mirror_region_z"] = round((m - mm_) / np.sqrt((sd_ ** 2 + sdm ** 2) / 2), 2)
        out["cand_mirror_z"] = round((cm_ - mm_) / sdm, 2)
    return out

# ---- 2. search zone: pial band minus skull-strip rim, white matter and deep nuclei
dist_mm = ndi.distance_transform_edt(brain, sampling=vox)
rim = brain & (dist_mm < RIM_MM)
If = Ic.copy(); If[~brain] = mu
shell = brain & (pial_sd >= -PIAL_IN_MM) & (pial_sd <= PIAL_OUT_MM) & ~np.isin(seg, WM + DEEP)
shell |= edge_band & ~np.isin(seg, WM + DEEP)
zone = shell & ~rim
# v5.3 skull band map (recorded for every candidate; E15 acts only with CSS_V53=1): a voxel is "skull-backed" when it
# lies near the brain-mask edge and at least 3 of the samples 3-6 mm outward along the pial normal are dark or outside the mask.
# cSS lines cortex that has bright CSF / cortex beyond it; the inner table of the skull is dark all the way out.
def _outward_dark():
    out = np.zeros(I.shape, bool); near = brain & (dist_mm < SKULL_EDGE_MM) & (z < Z_LOW)
    ii = np.nonzero(near)
    if not len(ii[0]): return out
    n_dark = np.zeros(len(ii[0]), np.int8); shp = np.array(I.shape)
    for step in (3.0, 4.0, 5.0, 6.0):
        q = [np.clip(np.round(ii[a] + step * normal[a][ii] / vox[a]).astype(int), 0, shp[a] - 1) for a in range(3)]
        n_dark += (~brain[q[0], q[1], q[2]]) | (z[q[0], q[1], q[2]] < Z_LOW)
    out[ii] = n_dark >= 3
    return out
SKULL = _outward_dark()

# ---- 3. curvilinear dark structures, slice by slice (candidate generation)
R = np.zeros_like(I)
_inpl = float(np.sqrt(vox[0] * vox[1]))
SATO_PX = [max(0.5, m / _inpl) for m in SATO_SIGMAS_MM]
if os.environ.get("CSS_SATO_LEGACY") == "1":     # v4.17 behaviour, for before/after comparisons on real data
    SATO_PX = [1.0, 2.0, 3.0]
for k in range(I.shape[2]):
    if I[:, :, k].max() > 0:
        R[:, :, k] = sato(If[:, :, k], sigmas=SATO_PX, black_ridges=True)
r_hi = np.percentile(R[shell], r_pct); r_lo = np.percentile(R[shell], R_PCT_LOW)
strong = zone & (z < z_thr) & (R > r_hi)
weak   = zone & (z < Z_LOW) & (R > r_lo)          # strong is a subset of weak
# v4.17 generation-stage record per voxel (bits): 1 search zone, 2 skull-strip rim, 4 WM / deep-nucleus label,
# 8 z < -2 (weak dark), 16 z < z_thr (strong dark), 32 ridge > weak pct, 64 ridge > strong pct,
# 128 in a component kept by hysteresis -> work/ID_gen.nii.gz, read by label_missed.py
GEN = (zone * 1 + rim * 2 + np.isin(seg, WM + DEEP) * 4 + (brain & (z < Z_LOW)) * 8 + (brain & (z < z_thr)) * 16
       + (brain & (R > r_lo)) * 32 + (brain & (R > r_hi)) * 64).astype(np.uint8)

# ---- 4. hemisphere map; hysteresis labelling separately in each hemisphere
Lm = np.isin(seg, LH) | ((seg >= 1000) & (seg < 2000))
Rm = np.isin(seg, RH) | (seg >= 2000)
hemiL = ndi.distance_transform_edt(~Lm, sampling=vox) <= ndi.distance_transform_edt(~Rm, sampling=vox)
dmid = np.where(hemiL, ndi.distance_transform_edt(hemiL, sampling=vox),
                ndi.distance_transform_edt(~hemiL, sampling=vox))
lab = np.zeros(I.shape, np.int32); n_raw = 0; nxt = 0; n_seeded = 0; LAB1 = lab
n_pieces = None; n_before_merge = None     # set by the merge step
PIECES = None                              # v5.1.1: pre-merge piece labels (None = no merging)
BAND = np.zeros(I.shape, bool)             # v5.3: single objects larger than any cSS focus (E12), set before pass 2
for side in (hemiL, ~hemiL):
    wl, nw = ndi.label(weak & side, structure=s3)
    n_raw += nw
    keep = np.unique(wl[strong & side]); keep = keep[keep > 0]
    n_seeded += len(keep)                  # v5.1: weak components without a strong seed are "not generated"
    remap = np.zeros(nw + 1, np.int32)
    remap[keep] = np.arange(1, len(keep) + 1) + nxt
    nz = wl > 0
    lab[nz] = remap[wl[nz]]
    nxt += len(keep)
GEN[lab > 0] |= 128
# v5.3.2: no voxels are removed after generation (v5.3.1 trimmed every voxel > 1.5 mm outside the cortex and dropped
# 3 reader-called cSS below the size gates; a skull-backed-only trim missed the dark band). Objects lying mostly
# outside the cortex are excluded by rule E17 instead, so every object keeps a traceable fate.
nib.save(nib.Nifti1Image(GEN, swi.affine), f"{base}/work/{subj}_gen.nii.gz"); del GEN
del R, wl, weak, strong

# ---- 4b. merge fragments of the same structure: a line broken by small gaps (noise, partial volume,
# slice-to-slice wobble) was reported as 2-3 separate candidates; also joins the two banks of a
# tram-track. Done per hemisphere so left and right never merge.
if MERGE_GAP_MM > 0 and lab.max() > 0:
    near_lab = ndi.distance_transform_edt(lab == 0, sampling=vox) <= MERGE_GAP_MM / 2
    merged = np.zeros_like(lab); nxt = 0
    for side in (hemiL, ~hemiL):
        gl, ng = ndi.label(near_lab & side, structure=s3)
        sel = (lab > 0) & side
        merged[sel] = gl[sel] + nxt
        nxt += ng
    # undo merges that would chain into an object longer than MERGE_MAX_MM: keep the pieces separate
    gmax = int(merged.max()); big = np.zeros(gmax + 1, bool)
    for g, sl in enumerate(ndi.find_objects(merged), 1):
        if sl is not None and np.sqrt(sum(((s_.stop - s_.start) * v) ** 2 for s_, v in zip(sl, vox))) > MERGE_MAX_MM:
            big[g] = True
    n_chains = int(big.sum())
    merged = np.where(big[merged], lab + gmax, merged)
    u = np.unique(merged[merged > 0]); remap = np.zeros(int(merged.max()) + 1, np.int32)
    remap[u] = np.arange(1, len(u) + 1)
    n_before_merge = int(len(np.unique(lab[lab > 0])))
    _orig = lab
    lab = remap[merged]
    _sel = _orig > 0
    _pairs = np.unique(np.stack([lab[_sel], _orig[_sel]]), axis=1)
    n_pieces = np.bincount(_pairs[0], minlength=int(lab.max()) + 1)    # original pieces per candidate
    PIECES = _orig                     # v5.1.1: pre-merge pieces kept for per-piece evidence
    del _sel, _pairs
    del near_lab, merged
    # v5.3.1 second pass (CSS_V53=1): first-pass objects within V53_GAP_MM of each other AND with the same cortical
    # region label (aparc) become one candidate - one continuous lining was reported as several fragments. Objects
    # in different regions never join (v5.3.0 joined cSS with neighbouring veins / normal cortex). The bridge may not
    # cross white matter / deep nuclei; a group longer than V53_MAX_MM keeps its first-pass objects.
    n_joined_v53 = 0
    # E12 extent is judged on the objects of the FIRST pass (one connected dark structure, e.g. the inner skull)
    _vol1 = np.bincount(lab.ravel()) * float(np.prod(vox))
    BAND = (_vol1 > E12_MM3)[lab] & (lab > 0); del _vol1
    LAB1 = lab                     # first-pass objects (before the v5.3 second merge pass rebinds `lab`); E22 per piece
    if V53 and V53_GAP_MM > MERGE_GAP_MM and lab.max() > 0:
        objs = ndi.find_objects(lab); n1 = len(objs); code1 = np.zeros(n1 + 1, np.int32)
        for g, sl in enumerate(objs, 1):
            if sl is None or BAND[sl][lab[sl] == g].any(): continue
            pd_ = tuple(slice(max(a.start - 2, 0), a.stop + 2) for a in sl)
            nb = seg[pd_][ndi.binary_dilation(lab[pd_] == g, iterations=2)]; nb = nb[nb >= 1000]
            if nb.size: code1[g] = int(np.bincount(nb).argmax())
        parent = np.arange(n1 + 1)
        def _find(a):
            while parent[a] != a: parent[a] = parent[parent[a]]; a = parent[a]
            return a
        pv = tuple(int(np.ceil(V53_GAP_MM / v)) + 1 for v in vox); blocked = np.isin(seg, WM + DEEP)
        for c in np.unique(code1[code1 > 0]):
            ids = np.nonzero(code1 == c)[0]
            if len(ids) < 2: continue
            bb = [objs[g - 1] for g in ids]
            box = tuple(slice(max(min(b[a].start for b in bb) - pv[a], 0), min(max(b[a].stop for b in bb) + pv[a], I.shape[a])) for a in range(3))
            sub = lab[box]; grp = np.isin(sub, ids)
            near = (ndi.distance_transform_edt(~grp, sampling=vox) <= V53_GAP_MM / 2) & ~(blocked[box] & ~grp)
            cl, _ = ndi.label(near, structure=s3)
            first = {}
            for g in ids:
                k_ = int(np.bincount(cl[sub == g]).argmax())
                if k_ in first: parent[_find(g)] = _find(first[k_])
                else: first[k_] = g
        root = np.array([_find(g) for g in range(n1 + 1)])
        # cap: a group whose bounding box is longer than V53_MAX_MM keeps its first-pass objects
        for r_ in np.unique(root[1:]):
            mem = np.nonzero(root == r_)[0]
            if len(mem) < 2: continue
            lo = np.min([[objs[g - 1][a].start for a in range(3)] for g in mem], 0); hi = np.max([[objs[g - 1][a].stop for a in range(3)] for g in mem], 0)
            if np.sqrt((((hi - lo) * np.array(vox)) ** 2).sum()) > V53_MAX_MM: root[mem] = mem
        u, inv = np.unique(root[1:], return_inverse=True); remap = np.zeros(n1 + 1, np.int32); remap[1:] = inv + 1
        lab = remap[lab]; n_joined_v53 = n1 - len(u)
        _sel = _orig > 0
        _pairs = np.unique(np.stack([lab[_sel], _orig[_sel]]), axis=1)
        n_pieces = np.bincount(_pairs[0], minlength=int(lab.max()) + 1)
        del _sel, _pairs, blocked

os.makedirs(f"{base}/work", exist_ok=True)
nib.save(nib.Nifti1Image((zone & (z < GROW_Z)).astype(np.uint8), swi.affine),
         f"{base}/work/{subj}_dark.nii.gz")
# v5.2: signed distance to the labelled pial boundary (mm; < 0 tissue, > 0 CSF / outside) for surface_aligned_patch.py
nib.save(nib.Nifti1Image(pial_sd.astype(np.float32), swi.affine), f"{base}/work/{subj}_pial_sd.nii.gz")

# ---- 5. 3-D Hessian shape (multi-scale) at dark voxels: plate (cSS) vs tube (vein)
need = brain & (z < Z_LOW) & (pial_sd > -PIAL_IN_MM)      # candidates + venous network voxels
need |= lab > 0
idx = np.nonzero(need)
best = np.full(len(idx[0]), -np.inf, np.float32)
eig = np.zeros((len(idx[0]), 3), np.float32); evec3 = np.zeros((len(idx[0]), 3), np.float32)
for s_mm in HESS_SIGMAS_MM:
    sg = mm2vox(s_mm); H = np.zeros((len(idx[0]), 3, 3), np.float32)
    for a in range(3):
        for b in range(a, 3):
            order = [0, 0, 0]; order[a] += 1; order[b] += 1
            h = ndi.gaussian_filter(If, sg, order=order)[idx] / (vox[a] * vox[b]) * s_mm ** 2   # v4.17: If
            H[:, a, b] = h; H[:, b, a] = h
    w, v = np.linalg.eigh(H)                              # ascending signed eigenvalues
    o = np.argsort(np.abs(w), axis=1)                     # sort by magnitude |l1|<=|l2|<=|l3|
    w = np.take_along_axis(w, o, 1); v3 = v[np.arange(len(v)), :, o[:, 2]]   # eigvec of l3
    upd = w[:, 2] > best                                  # dark structure: largest curvature > 0
    best[upd] = w[upd, 2]; eig[upd] = w[upd]; evec3[upd] = v3[upd]
    del H, w, v
l2, l3 = np.abs(eig[:, 1]), eig[:, 2]
tube_v = np.where(l3 > 0, l2 / np.maximum(np.abs(l3), 1e-6), np.nan).astype(np.float32)
TUBE = np.full(I.shape, np.nan, np.float32); TUBE[idx] = tube_v
ALIGN = np.full(I.shape, np.nan, np.float32)
ALIGN[idx] = np.abs(sum(evec3[:, a] * normal[a][idx] for a in range(3)))
del eig, evec3, best, tube_v

# ---- 6. venous network: dark tubular voxels in the subarachnoid space / cortex
vnet = need & (z < Z_LOW) & (TUBE > 0.5) & (pial_sd > -1.5)
# v4.11 vessel map that ALSO covers the white matter under the cortex: veins do not stop at the cortex -
# medullary / transcortical veins run radially into the WM, cortical veins continue along the surface.
# cSS is confined to the surface. WM is darker than cortex on SWI, so WM voxels are judged against WM.
_wmm = np.isin(seg, [2, 41])
wm_mu = float(np.median(Ic[_wmm])) if _wmm.any() else mu
wneed = _wmm & ((Ic - wm_mu) / sd < VES_WM_Z) & (pial_sd > -VES_WM_MM - PIAL_IN_MM) & ~need
if wneed.any():
    widx = np.nonzero(wneed); wbest = np.full(len(widx[0]), -np.inf, np.float32)
    weig = np.zeros((len(widx[0]), 3), np.float32)
    for s_mm in HESS_SIGMAS_MM:
        sg = mm2vox(s_mm); H = np.zeros((len(widx[0]), 3, 3), np.float32)
        for a in range(3):
            for b in range(a, 3):
                order = [0, 0, 0]; order[a] += 1; order[b] += 1
                h = ndi.gaussian_filter(If, sg, order=order)[widx] / (vox[a] * vox[b]) * s_mm ** 2
                H[:, a, b] = h; H[:, b, a] = h
        w = np.linalg.eigvalsh(H); w = np.take_along_axis(w, np.argsort(np.abs(w), axis=1), 1)
        upd = w[:, 2] > wbest; wbest[upd] = w[upd, 2]; weig[upd] = w[upd]
        del H, w
    # tube = two large curvatures and one small one; a round blob (haematoma, microbleed) is not a vessel
    _l3 = np.maximum(weig[:, 2], 1e-6)
    TUBE[widx] = np.where((weig[:, 2] > 0) & (np.abs(weig[:, 0]) / _l3 < 0.5), np.abs(weig[:, 1]) / _l3, np.nan)
    del weig, wbest
VES = ((need & (z < Z_LOW)) | wneed) & (TUBE > 0.5)        # dark tubes: band + WM
del wneed
# noise specks are not vessels: keep tube pieces at least VES_MIN_MM long
_vl, _ = ndi.label(VES, structure=s3)
_ok = np.zeros(int(_vl.max()) + 1, bool)
for n, sl_ in enumerate(ndi.find_objects(_vl), 1):
    if sl_ is not None:
        _ok[n] = np.sqrt(sum(((s_.stop - s_.start) * v) ** 2 for s_, v in zip(sl_, vox))) >= VES_MIN_MM
VES = _ok[_vl]; del _vl, _ok
deep_wm = _wmm & (ndi.distance_transform_edt(_wmm, sampling=vox) >= 1.5)   # WM proper, not the cortex border
# v4.16 dark structures for local vein tracking: dark voxels in pieces >= VES_MIN_MM (isolated noise voxels
# below z -2 would otherwise chain up through the tracker's gap bridging); includes wide dark structures
# such as a dural sinus, which are not Hessian tubes at sigma <= 1.6 mm
_dl, _ = ndi.label(brain & (z < Z_LOW), structure=s3)
_ok = np.zeros(int(_dl.max()) + 1, bool)
for n, sl_ in enumerate(ndi.find_objects(_dl), 1):
    if sl_ is not None:
        _ok[n] = np.sqrt(sum(((s_.stop - s_.start) * v) ** 2 for s_, v in zip(sl_, vox))) >= VES_MIN_MM
DARKS = _ok[_dl]; del _dl, _ok
# v5.0 Layer 1: mimic evidence (mimic_rules.py). Phase: filtered phase + scanner sign convention fitted on VES.
MIM = mimic_rules.MimicRejector(base, subj, swi, brain, vox, _si, ves=VES)
nib.save(nib.Nifti1Image(VES.astype(np.uint8), swi.affine), f"{base}/work/{subj}_vessels.nii.gz")   # for freeview
vl, nv = ndi.label(vnet | (lab > 0), structure=s3)
vext = np.zeros(nv + 1, np.float32)
for n, sl in enumerate(ndi.find_objects(vl), 1):
    if sl is not None:
        vext[n] = np.sqrt(sum(((s.stop - s.start) * v) ** 2 for s, v in zip(sl, vox)))

# ---- 7. mid-sagittal plane (hemisphere boundary) for the mirror check
bd = brain & hemiL & ndi.binary_dilation(~hemiL, structure=s3)
P = np.argwhere(bd).astype(np.float32) * vox
if len(P) > 100:
    pc = P.mean(0); mvec = np.linalg.svd(P[:: max(1, len(P) // 20000)] - pc, full_matrices=False)[2][2]
else:
    pc = np.array(I.shape) * vox / 2; mvec = np.array([1.0, 0, 0])
zmin3 = ndi.minimum_filter(z, size=3)
brain_in = ndi.binary_erosion(brain, structure=s3)      # one voxel inside the mask edge
def mirror_valid(pts):
    """v5.1.1: share of the candidate's mirror points that land inside the brain (mirror_dark_frac uses only those)"""
    p = pts * vox; q = p - 2 * ((p - pc) @ mvec)[:, None] * mvec[None, :]
    qi = np.round(q / vox).astype(int)
    ok = np.all((qi >= 0) & (qi < np.array(I.shape)), axis=1)
    ok[ok] = brain_in[qi[ok, 0], qi[ok, 1], qi[ok, 2]]
    return round(float(ok.mean()), 2) if len(ok) else np.nan
def mirror_dark(pts):
    p = pts * vox; q = p - 2 * ((p - pc) @ mvec)[:, None] * mvec[None, :]
    qi = np.round(q / vox).astype(int)
    ok = np.all((qi >= 0) & (qi < np.array(I.shape)), axis=1)
    qi = qi[ok]; ok[ok] = brain_in[qi[:, 0], qi[:, 1], qi[:, 2]]
    # v4.18: mirror points outside the brain read as dark (stripped background) -> ignored; NaN if most are outside
    if ok.mean() < 0.5:
        return float("nan")
    qi = np.round(q[ok] / vox).astype(int)
    return float((zmin3[qi[:, 0], qi[:, 1], qi[:, 2]] < Z_LOW).mean())

# ---- 7b. v5.3.4 mid-sagittal plane (same construction as scripts/midline_probe.py) for the E22 midline-sheet rule and the
#      viewer's midline hint: boundary between the two hemisphere territories (cortex + cerebral white matter labels)
_Lh = ((seg >= 1000) & (seg < 2000)) | (seg == 3) | (seg == 2); _Rh = ((seg >= 2000) & (seg < 3000)) | (seg == 42) | (seg == 41)
if _Lh.sum() > 1000 and _Rh.sum() > 1000:
    _dL = ndi.distance_transform_edt(~_Lh, sampling=vox); _dR = ndi.distance_transform_edt(~_Rh, sampling=vox)
    _hl = _dL <= _dR; _bd = _hl & ndi.binary_dilation(~_hl) & (_dL <= 8) & (_dR <= 8); _P0 = np.argwhere(_bd) * vox
    del _dL, _dR, _hl, _bd
    if len(_P0) >= 100:
        PL_C = _P0.mean(0); PL_N = np.linalg.svd(_P0[:: max(1, len(_P0) // 20000)] - PL_C, full_matrices=False)[2][2]
    else: PL_C = PL_N = None
    del _P0
else: PL_C = PL_N = None
del _Lh, _Rh
# v5.7 nearest-cortex label map (for the skull-base zone measure): label of the nearest cortical voxel of every voxel
_cxm = (seg >= 1000) & (seg < 3000)
if _cxm.any():
    _ni = ndi.distance_transform_edt(~_cxm, sampling=vox, return_distances=False, return_indices=True)
    NEAR_CX = seg[tuple(_ni)].astype(np.int32); del _ni
else: NEAR_CX = np.zeros(seg.shape, np.int32)
del _cxm
_Lcx = ((seg >= 1000) & (seg < 2000)) | (seg == 3); _Rcx = ((seg >= 2000) & (seg < 3000)) | (seg == 42)
if _Lcx.any() and _Rcx.any():
    DUALC = (ndi.distance_transform_edt(~_Lcx, sampling=vox) <= E25_REACH_MM) & (ndi.distance_transform_edt(~_Rcx, sampling=vox) <= E25_REACH_MM)
else: DUALC = np.zeros(seg.shape, bool)
# v5.8 compartments (recorded; see ZONE2 above)
_ctxL = (seg >= 1000) & (seg < 2000); _ctxR = (seg >= 2000) & (seg < 3000)
SULC = np.zeros(seg.shape, bool)
for _c in (_ctxL, _ctxR):
    if _c.any():
        _dil = ndi.distance_transform_edt(~_c, sampling=vox) <= ZONE2_R_MM
        SULC |= ndi.distance_transform_edt(_dil, sampling=vox) > ZONE2_R_MM
RIBSUL = (_ctxL | _ctxR | (SULC & ~DUALC)); del _dil
_ins = np.isin(seg, [1035, 2035]); _op = np.isin(seg, [1018, 1020, 1030, 1034, 1031, 1024, 1022, 2018, 2020, 2030, 2034, 2031, 2024, 2022])
SYLV = ((ndi.distance_transform_edt(~_ins, sampling=vox) <= SYLV_MM) & (ndi.distance_transform_edt(~_op, sampling=vox) <= SYLV_MM)) if _ins.any() and _op.any() else np.zeros(seg.shape, bool)
del _ctxL, _ctxR, _ins, _op, SULC
del _Lcx, _Rcx
# v5.7: ONE mid-sagittal plane - the mirror check (section 7) now uses this plane too (it had its own construction from the
# hemisphere map incl. deep nuclei). Only the recorded mirror columns can change; no rule uses them.
if PL_N is not None: pc, mvec = PL_C, PL_N
def axis_angle(mm_, pad_):
    """angle (degrees) between the object's long axis and the axial plane (array axis 2 = S-I): 0 = in the slice, 90 = through the slices; NaN if < 5 voxels"""
    if mm_.sum() < 5: return np.nan
    P = (np.argwhere(mm_) + np.array([s_.start for s_ in pad_])) * vox; Q = P - P.mean(0)
    w_, v_ = np.linalg.eigh(np.cov(Q.T)); return round(float(np.degrees(np.arcsin(min(abs(v_[2, -1]), 1.0)))), 0)
def plane_feats(mm_, pad_):
    """-> plane_dist_mm (median), cos_plane (|cos| thin axis vs plane normal), ext_major_mm; NaN without a plane"""
    if PL_N is None or mm_.sum() < 5: return dict(plane_dist_mm=np.nan, cos_plane=np.nan, ext_major_mm=np.nan)
    P = (np.argwhere(mm_) + np.array([s_.start for s_ in pad_])) * vox; Q = P - P.mean(0)
    w_, v_ = np.linalg.eigh(np.cov(Q.T)); ext = np.ptp(Q @ v_, axis=0)
    return dict(plane_dist_mm=round(float(np.median(np.abs((P - PL_C) @ PL_N))), 1), cos_plane=round(float(abs(v_[:, 0] @ PL_N)), 2),
                ext_major_mm=round(float(ext[2]), 1))
DARKG = zone & (z < GROW_Z); CTXB = (seg >= 1000) & (seg < 3000)
def _wide(mm_, pad_, mm_reach=22.0):
    """the object mask on a window `mm_reach` mm larger than its padded box (the padded box is only 3 voxels wide: too small to regrow a structure)"""
    ex = [int(np.ceil(mm_reach / v)) for v in vox]
    w = tuple(slice(max(s.start - e, 0), min(s.stop + e, n)) for s, e, n in zip(pad_, ex, I.shape))
    m = np.zeros(tuple(s.stop - s.start for s in w), bool)
    m[tuple(slice(p.start - s.start, p.stop - s.start) for p, s in zip(pad_, w))] = mm_
    return m, w
def cont_feats(mm_, pad_):
    """v5.10 continuity measures (recorded): darkness along the object and the minIP view.
    dark_cv / dark_gap_frac: the object's voxels are binned every 1.5 mm along its long axis; cv = SD / |mean| of the bin medians of the darkness z,
        gap = share of bins that are not dark (z > Z_LOW). An even, unbroken dark line -> both low.
    minip_len_mm / minip_cont: axial minimum-intensity slab of +-4 mm around the object; the dark (z < z_thr) 2-D component under the object's footprint;
        its longest extent and that extent / the object's own in-plane extent. A vessel becomes a long continuous tube on the minIP (cont >> 1)."""
    out = dict(dark_cv=np.nan, dark_gap_frac=np.nan, minip_len_mm=np.nan, minip_cont=np.nan)
    c = np.argwhere(mm_)
    if len(c) < 5: return out
    P = c * vox; Q = P - P.mean(0); w_, v_ = np.linalg.eigh(np.cov(Q.T)); t_ = Q @ v_[:, -1]; zz = z[pad_][mm_]
    b = np.floor((t_ - t_.min()) / 1.5).astype(int); med = np.array([np.median(zz[b == k]) for k in np.unique(b)])
    if len(med) >= 2: out["dark_cv"] = round(float(med.std() / max(abs(med.mean()), 1e-6)), 2); out["dark_gap_frac"] = round(float((med > Z_LOW).mean()), 2)
    m, w = _wide(mm_, pad_, 25.0); k = np.nonzero(m.any((0, 1)))[0]; h = int(np.ceil(4.0 / vox[2]))
    k0, k1 = max(k.min() - h, 0), min(k.max() + h + 1, m.shape[2])
    zs = np.where(brain[w][:, :, k0:k1], z[w][:, :, k0:k1], 0).min(2); foot = m.any(2)
    lab2, _n = ndi.label(zs < z_thr, structure=np.ones((3, 3)))
    ids = np.unique(lab2[foot]); ids = ids[ids > 0]
    if len(ids):
        comp = np.isin(lab2, ids); ext = lambda msk: float(np.sqrt(sum((np.ptp(a) * v_ + v_) ** 2 for a, v_ in zip(np.nonzero(msk), vox[:2]))))
        le = ext(comp); out["minip_len_mm"] = round(le, 1); out["minip_cont"] = round(le / max(ext(foot), 1e-6), 2)
    return out
def struct_feats(mm_, pad_):
    """v5.9: 3-D form of the whole dark structure -> struct_* columns (css_shape.struct_measures); v5.10: measured on a 22 mm wider window"""
    mm_, pad_ = _wide(mm_, pad_)
    sm = css_shape.struct_measures(DARKG[pad_], mm_, CTXB[pad_], pial_sd[pad_], vox, 20.0)
    return dict(struct_s1_mm=sm["s1"], struct_s2_mm=sm["s2"], struct_s3_mm=sm["s3"], struct_thick_mm=sm["thick"], struct_cls=sm["cls"], struct_cont=sm["cont"],
                struct_ctx_frac=sm["ctx"], struct_surf_cos=sm["cos"], struct_verdict=sm["verdict"])


def piece_sheet_feats(mm_, pad_):
    """E22 judged per first-pass piece: -> piece_sheet (1 if any piece of the object meets all three E22 conditions), ext_piece_max_mm (longest piece)"""
    if PL_N is None: return dict(piece_sheet=0, ext_piece_max_mm=np.nan)
    sub = LAB1[pad_]; ids = [g for g in np.unique(sub[mm_]) if g > 0]; best = 0.0; sheet = 0
    for g in ids:
        pm = mm_ & (sub == g)
        if pm.sum() < 5: continue
        f = plane_feats(pm, pad_); best = max(best, f["ext_major_mm"])
        if f["plane_dist_mm"] <= E22_PLANE_MM and f["cos_plane"] >= E22_COS and f["ext_major_mm"] >= E22_EXT_MM: sheet = 1
    return dict(piece_sheet=sheet, ext_piece_max_mm=round(best, 1) if ids else np.nan)

# ---- 8. lobar ICH: reader-drawn mask, else dark compact blobs in lobar tissue
ich_p = f"{base}/work/{subj}_ich.nii.gz"
lut = load_lut()
ART_CODES = [c for c, n in lut.items() if any(a in n for a in ARTIFACT_ZONES)]
if os.path.exists(ich_p):
    ich = nib.load(ich_p).get_fdata() > 0; ich_src = "drawn"
else:
    wm_mu = float(np.median(Ic[np.isin(seg, [2, 41])])) if np.isin(seg, [2, 41]).any() else mu
    lobar = np.isin(seg, [2, 41]) | cortex
    cand_ich = lobar & ((Ic - wm_mu) / sd < -3.0) & (pial_sd < -1.0)
    il, ni = ndi.label(cand_ich, structure=s3)
    ich = np.zeros_like(brain)
    for n, sl in enumerate(ndi.find_objects(il), 1):
        if sl is None: continue
        m = il[sl] == n
        if m.sum() * np.prod(vox) < ICH_MIN_MM3: continue
        if ndi.distance_transform_edt(np.pad(m, 1), sampling=vox).max() < ICH_MIN_RADIUS_MM: continue
        # a lobar haematoma lies in the tissue under the cortex. On P006 the auto-finder caught
        # skull-base susceptibility artifact (orbitofrontal) and the sagittal sinus / vertex veins:
        # reject blobs that are superficial, midline, at the skull-strip edge or in artifact zones
        if np.median(pial_sd[sl][m]) > -3.0: continue
        if np.median(dmid[sl][m]) < 5.0: continue
        if rim[sl][m].mean() > 0.2: continue
        if np.isin(seg[sl][m], ART_CODES).mean() > 0.3: continue
        ich[sl] |= m
    ich_src = "auto"
ich_dist = ndi.distance_transform_edt(~ich, sampling=vox) if ich.any() else np.full(I.shape, np.inf)

# ---- 9. optional FLAIR (acute convexity SAH is FLAIR-bright in the sulci; chronic cSS is not)
fl_p = f"{base}/work/{subj}_flair_swispace.nii.gz"
FL = None; fl_note = ""
if os.path.exists(fl_p) and not fresh(fl_p, f"{base}/data/{subj}_swi.nii"):
    fl_note = "FLAIR IGNORED (older than the SWI - re-run prep_anat.sh)"
elif os.path.exists(fl_p):
    FL = nib.load(fl_p).get_fdata().astype(np.float32)
    csf_ref = FL[csf_space & (FL > 0)]                      # v4.17 (was label 24 only)
    tis_ref = FL[tissue & brain & (FL > 0)]
    ctx_ref = FL[cortex & brain & (FL > 0)]
    if csf_ref.size and tis_ref.size and ctx_ref.size:
        f_mu = float(np.median(csf_ref)); f_sd = float(1.4826 * np.median(np.abs(tis_ref - np.median(tis_ref))) + 1e-6)
        fc_mu = float(np.median(ctx_ref))
    else:
        FL = None

# ---- 10. features per candidate
cortex_dist = ndi.distance_transform_edt(~cortex, sampling=vox)      # 0 inside cortex
# v4.9 normal anatomy: cerebellum/brainstem (tentorial interface) and basal cisterns
d_infra = ndi.distance_transform_edt(~np.isin(seg, INFRA), sampling=vox) if np.isin(seg, INFRA).any() \
    else np.full(I.shape, np.inf, np.float32)
d_vent = ndi.distance_transform_edt(~np.isin(seg, VENT), sampling=vox) if np.isin(seg, VENT).any() else np.full(I.shape, np.inf)
d_basal = ndi.distance_transform_edt(~np.isin(seg, BASAL), sampling=vox) if np.isin(seg, BASAL).any() \
    else np.full(I.shape, np.inf, np.float32)
pial_depth = ndi.distance_transform_edt(cortex | np.isin(seg, [2, 41]), sampling=vox)
step = 0.4; T_ = np.arange(step, TRAM_MAX_MM + step, step, dtype=np.float32)

def branches_per_10mm(mm):
    """2D skeleton per slice: branch points per 10 mm of centre-line (veins branch, cSS rarely)"""
    bp = 0; length = 0.0
    k8 = np.ones((3, 3)); k8[1, 1] = 0
    for k in range(mm.shape[2]):
        sl = mm[:, :, k]
        if sl.sum() < 3: continue
        sk = skeletonize(sl)
        nb = ndi.convolve(sk.astype(int), k8, mode="constant")
        bp += int((sk & (nb >= 3)).sum()); length += skeleton_length(sk, vox)
    return 10.0 * bp / max(length, 1.0)

def tram_track(pts):
    """From each bank voxel, walk along the surface normal across the sulcal CSF to the opposite
    bank. tram = opposite bank also dark AND the sulcal centre between them brighter than both
    (two separate dark lines = tram-track; a vein in the middle gives one central line)."""
    sdv = pial_sd[tuple(pts.T)]
    pts = pts[(sdv > -2.5) & (sdv < 1.0)]
    if len(pts) < 5: return np.nan, 0
    if len(pts) > 400: pts = pts[np.linspace(0, len(pts) - 1, 400).astype(int)]
    n = np.stack([normal[a][tuple(pts.T)] for a in range(3)], 1)
    q = pts[:, None, :] + T_[None, :, None] * n[:, None, :] / np.array(vox)   # voxel coords
    co = q.reshape(-1, 3).T
    sdr = ndi.map_coordinates(pial_sd, co, order=1, mode="nearest").reshape(q.shape[:2])
    zr = ndi.map_coordinates(z, co, order=1, mode="nearest").reshape(q.shape[:2])
    zs = z[tuple(pts.T)]
    hits = tram = 0
    for i in range(len(pts)):
        out = np.nonzero(sdr[i] > 0.3)[0]
        if not len(out): continue
        back = np.nonzero((sdr[i] <= 0) & (np.arange(len(T_)) > out[0]))[0]
        if not len(back): continue
        j = back[0]; hits += 1
        zo = zr[i, max(j - 2, 0): j + 5].min()
        zc_ = np.median(zr[i, out[0]: j][np.argsort(-sdr[i, out[0]: j])[:3]])   # sulcal midline
        if zo < Z_LOW and zc_ > max(zs[i], zo) + 1.0: tram += 1
    return (tram / hits if hits >= 5 else np.nan), hits

S3 = None; LAB3 = None; SEEDS3D_STATS = dict(active=False)
if SEEDS3D:
    S3, NZ3 = css_sheet3d.plate_filter(If, vox, shell, SHEET3D_SIGMAS_MM)
    s_hi3 = float(np.percentile(S3[shell], r_pct)); s_lo3 = float(np.percentile(S3[shell], R_PCT_LOW))
    strong3 = zone & (z < z_thr) & (S3 > s_hi3); weak3 = zone & (z < Z_LOW) & (S3 > s_lo3)
    LAB3 = np.zeros(I.shape, np.int32); _n3 = 0
    for side in (hemiL, ~hemiL):
        wl3, nw3 = ndi.label(weak3 & side, structure=s3)
        keep3 = np.unique(wl3[strong3 & side]); keep3 = keep3[keep3 > 0]
        rm3 = np.zeros(nw3 + 1, np.int32); rm3[keep3] = np.arange(1, len(keep3) + 1) + _n3
        nz3 = wl3 > 0; LAB3[nz3] = rm3[wl3[nz3]]; _n3 += len(keep3)
    GEN3 = ((zone * 1) + ((brain & (z < Z_LOW)) * 8) + ((brain & (z < z_thr)) * 16) + ((brain & (S3 > s_lo3)) * 32)
            + ((brain & (S3 > s_hi3)) * 64) + ((LAB3 > 0) * 128)).astype(np.uint8)
    nib.save(nib.Nifti1Image(GEN3, swi.affine), f"{base}/work/{subj}_gen_3d.nii.gz"); del GEN3, strong3, weak3
    _in2d = lab > 0; _near2d = ndi.binary_dilation(_in2d, structure=s3)
    _ids3 = np.unique(LAB3[LAB3 > 0]); _touch = np.unique(LAB3[_near2d & (LAB3 > 0)]); _only = np.setdiff1d(_ids3, _touch)
    _vv = float(np.prod(vox)); _cnt3 = np.bincount(LAB3.ravel(), minlength=int(LAB3.max()) + 1)
    _rows3 = []
    for _i in _only:
        if _cnt3[_i] * _vv < MIN_MM3: continue
        _c3 = np.argwhere(LAB3 == _i)
        if not passes_slice_gate(len(np.unique(_c3[:, 2])), vox[2]): continue
        _cm = np.round(_c3.mean(0)).astype(int)
        _rows3.append(dict(obj3d=int(_i), vox_i=int(_cm[0]), vox_j=int(_cm[1]), vox_k=int(_cm[2]), volume_mm3=round(float(_cnt3[_i] * _vv), 1),
                           hemi="L" if hemiL[tuple(_cm)] else "R", nearest_cortex_label=int(NEAR_CX[tuple(_cm)]),
                           sheet_med=round(float(np.median(S3[tuple(_c3.T)])), 4),
                           sheet_angle_deg=round(float(np.median(css_sheet3d.orientation_angle(NZ3[tuple(_c3.T)]))), 0), n_slices=int(len(np.unique(_c3[:, 2])))))
    pd.DataFrame(_rows3, columns=["obj3d", "vox_i", "vox_j", "vox_k", "volume_mm3", "hemi", "nearest_cortex_label", "sheet_med", "sheet_angle_deg", "n_slices"]) \
        .to_csv(f"{base}/work/{subj}_3d_only.csv", index=False)
    SEEDS3D_STATS = dict(active=True, sigmas_mm=list(SHEET3D_SIGMAS_MM), sheet_pct_strong=r_pct, sheet_pct_weak=R_PCT_LOW, s_hi=round(s_hi3, 4), s_lo=round(s_lo3, 4),
                         n_objects_3d=int(len(_ids3)), n_objects_2d=int(lab.max()), voxels_2d_covered_by_3d=round(float(LAB3[_in2d].astype(bool).mean()) if _in2d.any() else 0.0, 3),
                         n_3d_only_all=int(len(_only)), n_3d_only_listed=len(_rows3))
    del _in2d, _near2d, NZ3
objs = ndi.find_objects(lab)
rows = []
# v4.14: components removed by the generation gates are logged (work/ID_dropped.csv/.nii.gz), not shown
dropped = []
soft_log = []                                  # CSS_SOFT_GATES=1: objects that failed a generation gate but are kept (last, tier 4)
def drop(p, why, vol, n_sl=None, elong=None, gate="", measured=None, thr=None):
    c_ = np.asarray(p.centroid) / np.array(vox)              # regionprops centroid is in mm (spacing)
    dropped.append(dict(drop_id=len(dropped) + 1, reason=why, volume_mm3=round(vol, 1),
                        n_slices=n_sl, elongation=None if elong is None else round(elong, 1),
                        vox_i=int(round(c_[0])), vox_j=int(round(c_[1])), vox_k=int(round(c_[2])),
                        hemi="L" if hemiL[tuple(np.clip(np.round(c_).astype(int), 0, np.array(I.shape) - 1))] else "R",
                        _lab=p.label, gate_id=gate, measured=None if measured is None else round(float(measured), 3),
                        threshold=thr))                        # v5.1: gate id + measured value + threshold
for p in regionprops(lab, spacing=vox):
    vol = float(p.area)                         # already mm3 because spacing is given
    soft = ""
    if SOFT_GATES and int(round(vol / float(np.prod(vox)))) < 5:
        drop(p, "fewer than 5 voxels", vol, gate="G0_tiny", measured=vol, thr=5 * float(np.prod(vox))); continue
    if vol < MIN_MM3:
        if SOFT_GATES: soft = "G1_volume"; soft_log.append(dict(lab=p.label, gate_id=soft, measured=round(vol, 1), threshold=MIN_MM3))
        else: drop(p, f"volume <{MIN_MM3:g} mm3", vol, gate="G1_volume", measured=vol, thr=MIN_MM3); continue
    sl = objs[p.label - 1]
    pad = tuple(slice(max(s.start - 3, 0), s.stop + 3) for s in sl)
    mm = lab[pad] == p.label
    n_sl = int(mm.any(axis=(0, 1)).sum())
    if not passes_slice_gate(n_sl, vox[2]):
        if SOFT_GATES:
            soft = soft or "G2_slices"; soft_log.append(dict(lab=p.label, gate_id="G2_slices", measured=n_sl, threshold=MIN_SLICES))
        else: drop(p, f"<{MIN_SLICES} slices", vol, n_sl, gate="G2_slices", measured=n_sl, thr=MIN_SLICES); continue
    elong = p.axis_major_length / max(p.axis_minor_length, 1e-3)
    # elongation rejects round microbleeds, which are single pieces; a merged candidate (two banks,
    # a bent line) can be compact overall and is not rejected for it (v4.9.2)
    if elong < MIN_ELONG and (n_pieces is None or n_pieces[p.label] <= 1):
        if SOFT_GATES:
            soft = soft or "G3_elongation"; soft_log.append(dict(lab=p.label, gate_id="G3_elongation", measured=round(float(elong), 2), threshold=MIN_ELONG))
        else: drop(p, f"elongation <{MIN_ELONG:g}", vol, n_sl, elong, gate="G3_elongation", measured=elong, thr=MIN_ELONG); continue
    seg_nb = seg[pad][ndi.binary_dilation(mm, iterations=2)]
    nb = seg_nb[seg_nb >= 1000]
    # infratentorial only when clearly cerebellar/brainstem with little cerebral cortex nearby, so
    # occipital / inferior temporal cSS next to the tentorium is not dropped from the 0-4 score
    infra = bool(np.isin(seg_nb, INFRA).mean() > 0.5 and nb.size < 0.2 * seg_nb.size)
    if nb.size == 0 and not infra:
        drop(p, "no cortex label within 2 voxels", vol, n_sl, elong, gate="G4_no_cortex", measured=int(nb.size), thr=1); continue
    # hemisphere = majority of the candidate's own voxels in the hemisphere map (v4 fix: v3 counted
    # own L/R labels, but cSS lies in sulcal CSF where both counts are 0, so medial candidates
    # could take the region - and the score - of the opposite hemisphere)
    is_left = bool(hemiL[pad][mm].mean() >= 0.5)
    if nb.size:
        side = nb[nb < 2000] if is_left else nb[nb >= 2000]
        if side.size: nb = side
        code = int(np.bincount(nb).argmax())
    else:
        code = int(np.bincount(seg_nb[np.isin(seg_nb, INFRA)]).argmax())
    region = lut.get(code, str(code))
    pts = np.argwhere(mm) + [s.start for s in pad]
    contact   = float(near_surface[pad][mm].mean())
    depth     = float(-z[pad][mm].mean())
    cfrac     = float(cortex[pad][mm].mean())
    cdist     = float(np.median(cortex_dist[pad][mm]))
    # DEPRECATED: will be NaN'd in v5.1, use local_branch_per10mm (css_vessel.py) instead
    bdens     = branches_per_10mm(mm)
    nbh = ndi.binary_dilation(mm, structure=s2d, iterations=4) & cortex[pad]
    dp = pial_depth[pad]; zz = z[pad]
    outer = nbh & (dp <= 1.0); inner = nbh & (dp > 1.0) & (dp <= 2.5)
    sgrad = float(zz[inner].mean() - zz[outer].mean()) if outer.sum() >= 5 and inner.sum() >= 5 else float('nan')
    # v4 definition features
    psd = pial_sd[pad][mm]
    pdist = float(np.median(psd))
    bankf = float(((psd > -2.5) & (psd < 1.0)).mean())
    tub = float(np.nanmedian(TUBE[pad][mm])) if np.isfinite(TUBE[pad][mm]).any() else np.nan
    aln = float(np.nanmedian(ALIGN[pad][mm])) if np.isfinite(ALIGN[pad][mm]).any() else np.nan
    tram, _ = tram_track(pts)
    comps = np.unique(vl[pad][ndi.binary_dilation(mm, structure=s3)]); comps = comps[comps > 0]
    # DEPRECATED: will be NaN'd in v5.1 (saturates brain-wide on real SWI), use local_cont_max_mm instead
    vtree = float(vext[comps].max()) if len(comps) else 0.0
    # long axis vs the cortical surface normal: cSS runs ALONG the cortex (~0), penetrating / bridging
    # vessels and veins running down the middle of a sulcus run ALONG the normal (~1)
    pm = pts * np.array(vox); pm = pm - pm.mean(0)
    ua = np.linalg.svd(pm[:: max(1, len(pm) // 2000)], full_matrices=False)[2][0] if len(pm) >= 3 else np.zeros(3)
    axn = float(np.median(np.abs(sum(ua[a] * normal[a][tuple(pts.T)] for a in range(3)))))
    # v4.11 vessel continuation, bounded to VES_REACH_MM: follow dark TUBES connected to the candidate
    #  vessel_ext_mm = how far the tube continues beyond the candidate (cortical vein running on)
    #  vessel_wm_mm  = how far it runs on, in line with the candidate, inside the white matter (medullary vein)
    pv = tuple(int(np.ceil(VES_REACH_MM / v)) for v in vox)
    vb = tuple(slice(max(s_.start - q_, 0), min(s_.stop + q_, n_)) for s_, q_, n_ in zip(sl, pv, I.shape))
    cm = lab[vb] == p.label
    dcm = ndi.distance_transform_edt(~cm, sampling=vox)
    vv_ = VES[vb] & (dcm <= VES_REACH_MM)
    # 1-voxel gaps are bridged (thin veins break up at the cortex/WM contrast step and in noise);
    # distances are then measured on real vessel voxels only
    gl_, _ = ndi.label(ndi.binary_dilation(vv_, structure=s3) | cm, structure=s3)
    gid = np.unique(gl_[cm]); gid = gid[gid > 0]
    reach = np.isin(gl_, gid) & vv_ & ~cm
    ves_ext = float(dcm[reach].max()) if reach.any() else 0.0
    rwm = reach & deep_wm[vb] & (ich_dist[vb] > 3.0)          # a haematoma's rim is not a vessel
    # only WM vessel that carries STRAIGHT ON beyond the candidate's deep end:
    # a transcortical vein continues in line; cSS that merely touches an unrelated vessel does not
    # cone (half-angle VES_CONE_DEG) from the candidate's deepest point, pointing inward: the mean
    # inward surface normal + the centre->deepest-point direction (where a transcortical vein exits)
    if rwm.any():
        vx_ = np.array(vox); deep = pts[np.argmin(psd)] * vx_
        nin = -np.array([normal[a][tuple(pts.T)].mean() for a in range(3)])
        dvec = deep - pts.mean(0) * vx_
        ud = nin / (np.linalg.norm(nin) + 1e-6) + dvec / (np.linalg.norm(dvec) + 1e-6)
        ud = ud / np.linalg.norm(ud) if np.linalg.norm(ud) > 0.3 else ua
        fp = (np.argwhere(rwm) + [s_.start for s_ in vb]) * vx_ - deep
        inline = (fp @ ud) >= np.cos(np.radians(VES_CONE_DEG)) * np.linalg.norm(fp, axis=1)
        ves_wm = float(dcm[rwm][inline].max()) if inline.any() else 0.0
    else:
        ves_wm = 0.0
    # vessel_run_mm (recorded only): tube continuing straight on beyond EITHER end of the candidate's long
    # axis (a cortical vein runs on towards a sinus; cSS stops). Bounded by VES_REACH_MM.
    ves_run = 0.0
    if reach.any() and len(pts) >= 3:
        vx_ = np.array(vox); pm_ = pts * vx_; proj = (pm_ - pm_.mean(0)) @ ua
        fq = (np.argwhere(reach) + [s_.start for s_ in vb]) * vx_
        for end, sgn in ((pm_[np.argmax(proj)], 1.0), (pm_[np.argmin(proj)], -1.0)):
            fe = fq - end; ok_ = (fe @ (sgn * ua)) >= np.cos(np.radians(VES_CONE_DEG)) * np.linalg.norm(fe, axis=1)
            if ok_.any(): ves_run = max(ves_run, float(np.linalg.norm(fe[ok_], axis=1).max()))
    del dcm, gl_, reach, rwm
    # v4.16 bounded local vein tracking along the vessel map (recorded only, css_vessel.py)
    vt = css_vessel.local_tracking(cm, VES[vb], vox, VES_REACH_MM, band=(pial_sd[vb] > -PIAL_IN_MM) & ~np.isin(seg[vb], WM + DEEP),
                                   dark=DARKS[vb], midline=dmid[vb] < MIDLINE_END_MM)
    # DEPRECATED: will be NaN'd in v5.1, use mirror_surf_z (surface-mesh symmetry, v5.0.2) instead
    mdark = mirror_dark(pts)
    _own = mm & (seg[pad] == code) & cortex[pad]
    rref = region_ref(code, Ic[pad][mm], Ic[pad][_own])
    # v4.18 thickness (recorded only): half-width along the candidate's centre line
    rp = radius_profile(mm, vox)
    rad = dict(cand_radius_med_mm=round(float(np.median(rp)), 2) if len(rp) else np.nan,
               cand_radius_p95_mm=round(float(np.percentile(rp, 95)), 2) if len(rp) else np.nan,
               cand_radius_cv=round(float(np.std(rp) / np.mean(rp)), 2) if len(rp) and np.mean(rp) > 0 else np.nan)
    # microbleed vs cSS (Charidimou, AJNR 2016;37:E43): microbleeds are small (generally 2-5 mm),
    # round/oval and at least half surrounded by brain parenchyma - cSS lies on the surface / in CSF
    shell1 = ndi.binary_dilation(mm, structure=s3) & ~mm
    pfrac = float(tissue[pad][shell1].mean()) if shell1.any() else np.nan
    # bounding-box diagonal of the candidate itself (v4.14 B1: was pad width - 6, too small at the volume edge)
    ext_mm = float(np.sqrt(sum(((s_.stop - s_.start) * v) ** 2 for s_, v in zip(sl, vox))))
    cmb_like = bool(np.isfinite(pfrac) and pfrac >= 0.5 and ext_mm <= 10.0)
    # "well-defined" (consensus definition): darker than the 1-2 mm surroundings by >= MIN_EDGE_SD;
    # normal dark cortex fades gradually into its neighbourhood
    ring2 = ndi.binary_dilation(mm, structure=s3, iterations=2) & ~mm & brain[pad]
    edge_c = float(np.median(z[pad][ring2]) - np.median(z[pad][mm])) if ring2.any() else np.nan
    idist = float(ich_dist[pad][mm].min())
    fz = fcz = fbf = np.nan
    if FL is not None:
        near3 = ndi.binary_dilation(mm, structure=s3, iterations=max(1, int(round(3 / vox[0])))) & (FL[pad] > 0)
        ring = near3 & (pial_sd[pad] > 0.5)                       # sulcal CSF: acute convexity SAH
        if ring.sum() >= 5:
            fz = float(np.median((FL[pad][ring] - f_mu) / f_sd))
            fbf = float((((FL[pad][ring] - f_mu) / f_sd) > 3.0).mean())   # v5.1.2 share of bright CSF samples
        ctxn = near3 & cortex[pad]                                # cortex: oedema of cortical vein thrombosis
        if ctxn.sum() >= 5: fcz = float(np.median((FL[pad][ctxn] - fc_mu) / f_sd))
    mim = MIM.evaluate(mm, pad, tissue[pad], fz, fcz, dark_pad=z[pad] < Z_LOW)   # v5.0, recorded; acts only with CSS_USE_MIMIC=1
    artz      = any(a in region for a in ARTIFACT_ZONES)
    # v5.3 (recorded always): midline share, distance to the brain-mask edge, skull-backed share
    v53 = dict(midline_frac=round(float((dmid[pad][mm] < E13_MID_MM).mean()), 2),
               mask_edge_mm=round(float(np.median(dist_mm[pad][mm])), 1),
               skull_frac=round(float(SKULL[pad][mm].mean()), 2), v53_active=int(V53), _band=bool(BAND[pad][mm].any()),
               vent_frac=round(float((d_vent[pad][mm] <= E16_MM).mean()), 2),
               out_frac=round(float((pial_sd[pad][mm] > V53_OUT_MM).mean()), 2), **plane_feats(mm, pad), **piece_sheet_feats(mm, pad), **struct_feats(mm, pad), **cont_feats(mm, pad), ich_contact_frac=round(float((ich_dist[pad][mm] <= 2.0).mean()), 2),
               skullbase_frac=round(float(np.isin(NEAR_CX[pad][mm], E24_LABELS).mean()), 2),
               dual_contact_frac=round(float(DUALC[pad][mm].mean()), 2), zone2_frac=round(float(RIBSUL[pad][mm].mean()), 2), sylvian_frac=round(float(SYLV[pad][mm].mean()), 2), axis_angle_deg=axis_angle(mm, pad),
               sheet3d_med=round(float(np.median(S3[pad][mm])), 4) if S3 is not None else np.nan,
               sheet3d_overlap=round(float((LAB3[pad][mm] > 0).mean()), 2) if LAB3 is not None else np.nan)
    midz      = bool(np.median(dmid[pad][mm]) < 5.0)
    # off-surface tube. vein_tree_mm is recorded only: on real SWI (P006) the dark tubular network
    # along the cortex merges into one brain-wide component (255 mm for most candidates)
    vein_like = bool(pdist > 0.3 and (np.isnan(tub) or tub > 0.4))
    # v5.1.1 per-piece evidence of merged objects (css_pieces.py), valid-sample fractions, missing inputs
    piece = dict(css_pieces.piece_evidence(mm, None if PIECES is None else PIECES[pad], pial_sd[pad], TUBE[pad],
                                           PIECE_MIN_FRAC),
                 merge_gap_mm=MERGE_GAP_MM, mixed_object_review=0,
                 ref_valid_frac=round(float(REF_OK[pad][mm].mean()), 2),
                 mirror_valid_frac=mirror_valid(pts),
                 missing_t1_anatomy=int(not T1_ANAT), missing_flair_features=int(FL is None),
                 missing_phase_features=int(MIM.hp is None))
    # v5.1.2 feature-spec families (css_features.py; recorded only)
    feat = dict(css_features.position_features(mm, pial_sd[pad], CSF_DEPTH[pad], NEAR_CSF[pad], SULC_D[pad]),
                **css_features.compactness_features(mm, vox), **css_features.path_features(mm, vox),
                **css_features.darkness_features(z[pad][mm]), flair_csf_bright_frac=round(fbf, 2) if np.isfinite(fbf) else np.nan)
    feat["feature_qc_flags"] = css_features.qc_flags({**piece, **mim})
    feat["feature_schema_version"] = css_features.FEATURE_SCHEMA
    longs     = bool(n_sl * vox[2] > 40.0)    # > 40 mm top-to-bottom (sinus / large veins)
    # v3 score (kept for comparison)
    s3_ = depth * (0.25 + contact) * np.log1p(vol)
    for flag, f in ((artz, 0.5), (midz, 0.5), (cfrac < 0.35, 0.6), (longs, 0.5)):
        if flag: s3_ *= f
    # v4 score: darkness x how well each part of the definition is met (transparent, untrained)
    on_surf = float(np.exp(-((pdist + 0.5) / 1.5) ** 2))          # subpial: ~ -0.5 mm
    sheet = 1.0 - (tub if np.isfinite(tub) else 0.5)
    # sqrt: darkness is damped - on real data (P006) veins were DARKER than cSS (AUC 0.37)
    s4 = np.sqrt(max(depth, 0.0)) * (0.25 + on_surf) * (0.25 + sheet) * (0.5 + (aln if np.isfinite(aln) else 0.5)) \
         * (1.0 + (tram if np.isfinite(tram) else 0.0))
    # mirror_dark_frac is recorded only (venous anatomy can be asymmetric, cSS can be bilateral)
    for flag, f in ((artz, 0.5), (midz, 0.7),
                    (longs, 0.5), (infra, 0.3)):
        if flag: s4 *= f
    if USE_MIMIC and mim["_flair_class"] != "none":            # v5.0 soft penalty: possible acute cSAH / thrombosis
        s4 *= 0.5; mim["mimic_reason"] += " [score x0.5, CSS_USE_MIMIC=1]"
    # two separate, rule-based evidence summaries for the reader (0-1, NOT probabilities -
    # untrained; to be replaced by a model fitted on expert labels):
    #  cSS  = on the surface, sheet-like, parallel to the cortex, tram-track, on a bank
    #  vein = tube-like, out in the sulcal CSF, not parallel to the cortex
    fin = lambda v: v if np.isfinite(v) else None
    ce = [on_surf, 1 - tub if np.isfinite(tub) else None, fin(aln), fin(tram), bankf]
    ve = [fin(tub), 1 / (1 + np.exp(-(pdist - 0.3) / 0.5)), 1 - aln if np.isfinite(aln) else None,
          axn, min(ves_wm / VES_EXCL_WM_MM, 1.0)]
    css_ev = float(np.mean([v for v in ce if v is not None]))
    vein_ev = float(np.mean([v for v in ve if v is not None]))
    c0 = pts.mean(0)
    rows.append(dict(soft_gate_fail=soft, hemi="L" if is_left else "R", region=region, label=code,
                     volume_mm3=round(vol, 1), n_slices=n_sl, single_slice=int(n_sl < MIN_SLICES), elongation=round(elong, 1),
                     surface_contact=round(contact, 2), darkness_z=round(depth, 1),
                     artifact_zone=int(artz), midline_zone=int(midz),
                     score=round(s4 if RANK == "v4" else s3_, 2),
                     vox_i=int(round(c0[0])), vox_j=int(round(c0[1])), vox_k=int(round(c0[2])),
                     cortex_frac=round(cfrac, 2), cortex_dist_mm=round(cdist, 2),
                     branch_per10mm=round(bdens, 2), surface_gradient=round(sgrad, 2),
                     vein_like=int(vein_like), long_structure=int(longs),
                     pial_dist_mm=round(pdist, 2), bank_frac=round(bankf, 2),
                     tube_ratio=round(tub, 2), surface_alignment=round(aln, 2),
                     tram_frac=round(tram, 2), vein_tree_mm=round(vtree, 1),
                     mirror_dark_frac=round(mdark, 2), ich_dist_mm=round(min(idist, 999.0), 1),
                     parenchyma_frac=round(pfrac, 2), extent_mm=round(ext_mm, 1), cmb_like=int(cmb_like),
                     near_ich_suggest=int(idist <= 5.0), infratentorial=int(infra),
                     flair_csf_z=round(fz, 2), flair_bright=int(np.isfinite(fz) and fz > 3.0),
                     flair_ctx_z=round(fcz, 2), flair_ctx_bright=int(np.isfinite(fcz) and fcz > 3.0),
                     css_evidence=round(css_ev, 2), vein_evidence=round(vein_ev, 2),
                     edge_contrast=round(edge_c, 2), _wz=float((swi.affine @ np.r_[c0, 1])[2]),
                     infra_frac=round(float((d_infra[pad][mm] <= INFRA_MM).mean()), 2),
                     basal_frac=round(float((d_basal[pad][mm] <= BASAL_MM).mean()), 2),
                     vessel_ext_mm=round(ves_ext, 1), vessel_wm_mm=round(ves_wm, 1), vessel_run_mm=round(min(ves_run, VES_REACH_MM), 1), axis_normal=round(axn, 2),
                     score_v3=round(s3_, 2), score_v4=round(s4, 2), _lab=p.label,
                     n_pieces=int(n_pieces[p.label]) if n_pieces is not None else 1, **vt, **rad, **rref, **{k: v for k, v in mim.items() if not k.startswith('_')}, **piece, **feat, **v53))

# CSV columns up to "long_structure" are consumed by export_review.py / the workbook: keep them
cols = ["cand_id", "hemi", "region", "label", "volume_mm3", "n_slices", "elongation",
        "surface_contact", "darkness_z", "artifact_zone", "midline_zone", "score",
        "vox_i", "vox_j", "vox_k", "cortex_frac", "cortex_dist_mm", "branch_per10mm", "surface_gradient",
        "vein_like", "long_structure",
        "pial_dist_mm", "bank_frac", "tube_ratio", "surface_alignment", "tram_frac", "vein_tree_mm",
        "mirror_dark_frac", "ich_dist_mm", "near_ich_suggest", "infratentorial", "flair_csf_z",
        "parenchyma_frac", "extent_mm", "cmb_like",
        "flair_bright", "flair_ctx_z", "flair_ctx_bright", "css_evidence", "vein_evidence",
        "edge_contrast", "infra_frac", "basal_frac", "rel_height",
        "vessel_ext_mm", "vessel_wm_mm", "vessel_run_mm", "axis_normal", "score_v3", "score_v4", "accept",
        "qc_status", "rule_version", "n_pieces",                                   # v4.14, appended
        "cand_geodesic_mm", "local_cont_max_mm", "local_cont_min_mm", "local_cont_total_mm",  # v4.16,
        "terminal_ends", "local_net_mm", "local_branch_points", "local_branch_per10mm",       # recorded only
        "end_type_max", "end_type_min", "review_tier", "tier_reason",
        "cand_radius_med_mm", "cand_radius_p95_mm", "cand_radius_cv", "net_radius_med_mm", "net_radius_p95_mm",                        # v4.18, recorded only
        "region_z", "region_dark_frac", "mirror_region_z", "cand_mirror_z"]                         # v4.19.2, recorded only
# v5.0 columns: appended LAST in both files (the excluded CSV ends with exclusion_confidence before them)
V50_COLS = ["mimic_score", "mimic_class", "mimic_reason", "phase_z", "mb_cluster_n", "phase_r",   # mimic_rules.py
            # v5.1.1: per-piece evidence of merged objects, valid-sample fractions, missing inputs
            "piece_vol_vox", "piece_pial_mm", "piece_tube", "piece_vein_frac", "mixed_object", "mixed_object_review",
            "merge_gap_mm", "ref_valid_frac", "mirror_valid_frac", "region_n_vox",
            "missing_t1_anatomy", "missing_flair_features", "missing_phase_features",
            # v5.1.2 feature-spec families (css_features.py, mimic_rules.py), recorded only
            "phase_valid_frac", "phase_polarity_frac", "pial_sd_p10_mm", "pial_sd_p90_mm", "surface_contact_frac_1mm",
            "surface_contact_frac_2mm", "csf_adjacent_frac", "csf_depth_mm", "sulcal_depth_mm",
            "equivalent_sphere_diameter_mm", "compactness_3d", "sphericity", "elongation_3d", "flatness_3d",
            "path_length_mm", "tortuosity", "darkness_z_p10", "dark_frac_z2", "dark_frac_z3", "dark_frac_z4",
            "flair_csf_bright_frac", "feature_qc_flags", "feature_schema_version",
            "review_priority_rank", "review_priority", "review_priority_reason",                # v5.1.3 (css_tiers.py)
            "midline_frac", "mask_edge_mm", "skull_frac", "v53_active",                         # v5.3, appended
            "vent_frac", "out_frac", "plane_dist_mm", "cos_plane", "ext_major_mm", "skullbase_frac", "dual_contact_frac",               # v5.3.1 / v5.3.2 / v5.3.4 / v5.7, appended
            "soft_gate_fail", "axis_angle_deg", "sheet3d_med", "sheet3d_overlap", "piece_sheet", "ext_piece_max_mm", "zone2_frac", "sylvian_frac",
            "struct_s1_mm", "struct_s2_mm", "struct_s3_mm", "struct_thick_mm", "struct_cls", "struct_cont", "struct_ctx_frac", "struct_surf_cos", "struct_verdict",
            "dark_cv", "dark_gap_frac", "minip_len_mm", "minip_cont", "ich_contact_frac", "confidence_pct", "confidence_why", "conf_guard", "single_slice"]                                                                    # v5.7 audit branch: "" or the generation gate the object failed (CSS_SOFT_GATES=1)
cols = cols + V50_COLS

# ---- 11. exclusions (v4.8) - each with an explicit, definition-based reason
# height is measured within the CEREBRUM (cortex + cerebral WM), so 0 = floor of the temporal/frontal
# lobes (skull base), 1 = vertex; the cerebellum below does not stretch the scale
_cer = (cortex | np.isin(seg, [2, 41]))[::4, ::4, ::4]
_src = _cer if _cer.any() else brain[::4, ::4, ::4]
_bz = (swi.affine @ np.c_[np.argwhere(_src) * 4, np.ones(int(_src.sum()))].T)[2]
z_lo, z_hi = float(_bz.min()), float(_bz.max())
for r in rows: r["rel_height"] = round((r["_wz"] - z_lo) / max(z_hi - z_lo, 1e-6), 2)
# coverage: a slab that is cut off at the bottom has no skull base in it - "lowest 20 %" would then
# remove ordinary cortex (P010: lateral occipital lesion on slice 6)
_zax = int(np.argmax(np.abs(swi.affine[2, :3])))
_area = brain.sum(axis=tuple(a for a in range(3) if a != _zax)).astype(float)
_nz = np.nonzero(_area)[0]
_bot = _nz[0] if swi.affine[2, _zax] > 0 else _nz[-1]
FULL_BOTTOM = bool(len(_nz) and _area[_bot] < 0.2 * _area.max())
# v4.14: each rule has an id + the version that introduced or last changed it (rule_version column) and a
# confidence for the excluded list. Confidence is a reading aid, not validated: "low" marks rules with
# little real-data support or a case whose QC status is not ok (see review/ID_qc.json).
RULE_CONF = {"E1": "high" if T1_ANAT else "medium", "E2": "medium", "E3": "medium", "E4": "high",
             "E5": "medium", "E6": "medium", "E7": "medium", "E8": "low", "E9": "medium",
             "E10": "low", "E11": "low",                       # v5.0 mimic rules: no real-data support yet
             "E12": "low", "E13": "low", "E14": "low", "E15": "low", "E16": "low", "E17": "low",
             "E18": "low", "E19": "low", "E20": "low", "E21": "low", "E22": "low", "E24": "low", "E25": "low", "E26": "low", "E27": "low", "E28": "low", "E29": "low", "E30": "low"}   # v5.3: chosen on M02-M11, not validated
def exclusion(r):
    """-> (rule_version, reason); ("", "") = kept. v5.1.1 CSS_MIXED_REVIEW=1: a mixed merged object (pieces disagree)
    is not removed whole by a vein rule (E5 / E6 / E7); it is shown with mixed_object_review = 1"""
    rv, why = exclusion_v4(r)
    if not rv and CONF and CONF_CUT_OK and not KEEP_ALL and np.isfinite(r["confidence_pct"]) and r["confidence_pct"] < float(CONF_MODEL.get("cut_pct", 0)):
        rv, why = "E30@v5.10", f"low confidence ({r['confidence_pct']:.0f} % < {float(CONF_MODEL['cut_pct']):.0f} %): {r['confidence_why']}"
    if css_pieces.rescue_mixed(rv, r.get("mixed_object"), MIXED_REVIEW):
        r["mixed_object_review"] = 1
        return "", ""
    return rv, why
def exclusion_v4(r):
    if KEEP_ALL: return "", ""
    if r["infratentorial"] or r["infra_frac"] >= (0.3 if T1_ANAT else 0.5):
        return "E1@v4.9.2", "infratentorial / tentorial interface (cerebellum, brainstem) - not cSS by definition"
    if T1_ANAT and r["basal_frac"] >= 0.3:
        return "E2@v4.9.2", "basal cisterns (circle of Willis / basal veins next to brainstem, mesial temporal lobe)"
    if T1_ANAT and FULL_BOTTOM and r["rel_height"] < 0.2:
        return "E3@v4.9.2", "skull base (lowest 20 % of the cerebrum)"
    if r["extent_mm"] < MIN_EXTENT_MM: return "E4@v4.8", f"speck (<{MIN_EXTENT_MM:g} mm)"
    if V53:                          # v5.3 opt-in rules (CSS_V53=1); every excluded object stays in ID_excluded.csv
        if r["skull_frac"] >= E15_SKULL and r["pial_dist_mm"] > 0:    # v5.3.3: 0.70 (0.50 excluded 3 cSS)
            return "E15@v5.3.3", "skull band: outside the cortex and dark all the way out to the brain-mask edge (inner skull / dura)"
        if r["_band"]:
            return "E12@v5.3.1", f"extent: one connected object larger than any cSS focus (> {E12_MM3:g} mm3) - band artifact"
        if r["vent_frac"] >= E16_FRAC:
            return "E16@v5.3.1", "ventricle / choroid plexus (within 3 mm of a ventricle label)"
        if r["out_frac"] >= E17_FRAC and r["cortex_frac"] < E17_CTX and not (np.isfinite(r["tram_frac"]) and r["tram_frac"] >= 0.2):
            return "E17@v5.3.2", f"outside the cortex: most of it lies > {V53_OUT_MM:g} mm outside the brain surface (skull / dura band)"
        if r["volume_mm3"] > E20_VOL and r["skull_frac"] >= E19_SKULL:
            return "E20@v5.3.3", f"skull-backed and larger than any cSS focus read (> {E20_VOL:g} mm3)"
        if r["darkness_z"] > E19_DARK and r["skull_frac"] >= E19_SKULL:
            return "E19@v5.3.3", f"skull-backed and darker than any cSS read (> {E19_DARK:g} SD): skull / air-bone signal void"
        if r["cortex_frac"] < E21_CTX and r["skull_frac"] >= E19_SKULL:
            return "E21@v5.3.3", f"skull-backed and off the cortex (cortex share < {E21_CTX:g})"
        if np.isfinite(r["edge_contrast"]) and r["edge_contrast"] < E18_EDGE:
            return "E18@v5.3.3", f"ill-defined (edge contrast < {E18_EDGE:g} SD)"
        if ZONE2 and r["zone2_frac"] < ZONE2_FRAC:
            return "E26@v5.8", f"outside cortex and sulci: only {100 * r['zone2_frac']:.0f} % in cortex or sulcal CSF (convexity CSF / dura / skull / fissure)"
        if ZONE2 and r["sylvian_frac"] >= SYLV_FRAC:
            return "E27@v5.8", f"Sylvian fissure: {100 * r['sylvian_frac']:.0f} % between insula and operculum (middle cerebral artery branches / Sylvian veins)"
        if STRUCT and r["struct_cls"] == "BALL" and np.isfinite(r["struct_ctx_frac"]) and r["struct_ctx_frac"] <= STRUCT_BALL_CTX:
            return "E28@v5.9", f"compact 3-D ball ({r['struct_s1_mm']:.0f} mm) outside the cortex: microbleed / bubble-like"
        if STRUCT and r["struct_cls"] == "TUBE" and r["struct_cont"] >= STRUCT_TUBE_CONT and np.isfinite(r["struct_surf_cos"]) and r["struct_surf_cos"] >= STRUCT_TUBE_COS:
            return "E29@v5.9", f"round 3-D tube that runs on {r['struct_cont']:.1f}x beyond the object and leaves the surface: vessel"
        if r["dual_contact_frac"] >= E25_FRAC:
            return "E25@v5.7", (f"interhemispheric fissure: left and right cortex both within {E25_REACH_MM:g} mm of {100 * r['dual_contact_frac']:.0f} % "
                                f"of the object (between the hemispheres: falx / sinus / fissure vessels)")
        if r["midline_frac"] >= E13_FRAC_V533:                         # v5.3.3: any depth (user: exclude the fissure)
            return "E13@v5.3", "midline: in the interhemispheric fissure (falx / sagittal sinus / midline veins)"
        if ((r["piece_sheet"] == 1) if E22_PIECES else (np.isfinite(r["plane_dist_mm"]) and r["plane_dist_mm"] <= E22_PLANE_MM and r["cos_plane"] >= E22_COS
                and r["ext_major_mm"] >= E22_EXT_MM)):
            return "E22@v5.3.4", (f"midline sheet: a flat sheet {r['ext_major_mm']:.0f} mm long lying in the mid-sagittal plane "
                                  f"({r['plane_dist_mm']:.1f} mm from it) - falx / sagittal sinus / fissure veins")
        if r["skullbase_frac"] >= E24_FRAC:
            return "E24@v5.7", (f"skull-base cortex zone: {100 * r['skullbase_frac']:.0f} % of the object lies on orbitofrontal / frontal pole / "
                                f"temporal pole cortex (air-bone susceptibility surface)")
        if "orbitofrontal" in r["region"] and r["mask_edge_mm"] < E14_EDGE_MM:
            return "E14@v5.3", "orbitofrontal air-bone susceptibility zone"
    tub_, tram_ = r["tube_ratio"], r["tram_frac"]
    if r["pial_dist_mm"] > 0.5 and np.isfinite(tub_) and tub_ > 0.45 and not (np.isfinite(tram_) and tram_ >= 0.2):
        return "E5@v4.8", "vein: tubular, in the middle of the sulcal CSF"
    if r["vessel_wm_mm"] >= VES_EXCL_WM_MM and r["axis_normal"] >= VES_EXCL_AXIS \
            and not (np.isfinite(tram_) and tram_ >= 0.4):     # clear tram-track (cSS ~0.9) overrides
        return "E6@v4.11", "vessel: continues as a tube into the white matter, runs perpendicular to the cortex"
    # v4.12 off the cortex (T1 anatomy only): cSS coats the pial surface, so it always touches the cortex.
    # A dark line lying wholly out in the sulcal CSF is a vein. Known P006 cSS: cortex_frac >= 0.55,
    # pial_dist <= -0.57; P011 false positives: median 0.16 / +1.22 mm -> thresholds with a wide margin
    if T1_ANAT and r["cortex_frac"] < OFF_CTX_FRAC and r["pial_dist_mm"] > OFF_PIAL_MM \
            and not (np.isfinite(tram_) and tram_ >= 0.2):
        return "E7@v4.12", "off the cortex: lies in the sulcal CSF without touching the cortex (vein)"
    if T1_ANAT and FULL_BOTTOM and r["artifact_zone"] and r["rel_height"] < 0.4:   # v4.17: T1 only, like E2/E3
        return "E8@v4.17", "skull-base susceptibility artifact zone"
    if np.isfinite(r["edge_contrast"]) and r["edge_contrast"] < MIN_EDGE_SD:
        return "E9@v4.8", "faint / ill-defined (normal dark cortex)"
    # v5.0 mimic rules (opt-in, CSS_USE_MIMIC=1; checked last, so the v4 reason wins where both apply)
    if USE_MIMIC and r["mimic_class"] == "calcification" and r["mimic_score"] >= MIMIC_CALC_EXCL:
        return "E10@v5.0", "calcification: diamagnetic on the phase (" + r["mimic_reason"].split(";")[0] + ")"
    if USE_MIMIC and r["mimic_class"] == "mb_cluster" and r["mimic_score"] >= MIMIC_MB_EXCL:
        return "E11@v5.0", f"cluster of microbleeds ({int(r['mb_cluster_n'])} compact parenchymal blobs), not a band"
    return "", ""
# ---- 11b. case QC (v4.14, reported only - changes no candidate)
QC = css_qc.case_qc(base, subj, swi, I, If, seg, brain, tissue, cortex, pial_sd, normal, rim, hemiL, vox,
                    T1_ANAT, FULL_BOTTOM)
if T1_ANAT and QC.get("registration_ok") is False and not ALLOW_BAD_REG:
    update_manifest(base, subj, "detect_refused", dict(pipeline_version=RULESET, run_at=pd.Timestamp.now().isoformat(timespec="seconds"), reason="registration_failed",
                    label_shift_mm=QC.get("label_shift_mm"), edge_bias_mm=QC.get("edge_bias_mm"), limit_mm=css_qc.EDGE_LOW_CONF_MM,
                    note="no list was written; existing lists, calls and fates are unchanged"))
    print(f"{subj}: STOPPED - registration not acceptable: {QC.get('registration_note')}. No candidate list was written and nothing existing was changed "
          f"[review/{subj}_qc.json]. Re-register (prep_anat.sh) or, to proceed knowingly, CSS_ALLOW_BAD_REG=1.")
    sys.exit(5)
if QC_STRICT and QC["status"] == "insufficient_quality":
    # v5.0 CSS_QC_STRICT=1: the detector's assumptions do not hold -> no candidates are offered for this case
    os.makedirs(f"{base}/review", exist_ok=True)
    pd.DataFrame(columns=cols).to_csv(f"{base}/review/{subj}_candidates.csv", index=False)
    pd.DataFrame(columns=["excl_id", "reason"]).to_csv(f"{base}/review/{subj}_excluded.csv", index=False)
    for f_ in ("candidates", "excluded"):
        nib.save(nib.Nifti1Image(np.zeros(I.shape, np.int16), swi.affine), f"{base}/review/{subj}_{f_}.nii.gz")
    update_manifest(base, subj, "detect", dict(pipeline_version=RULESET, args=sys.argv[1:], qc_status=QC["status"],
                    qc_strict=True, n_candidates=0, note="CSS_QC_STRICT=1: case cannot be scored",
                    fates=dict(raw_components=int(n_raw), not_generated_unseeded=int(n_raw - n_seeded),
                               objects=int(lab.max()), qc_blocked=int(lab.max()), shown=0),
                    environment=environment_record()))
    print(f"{subj}: QC insufficient_quality ({'; '.join(QC['reasons'])}) - CSS_QC_STRICT=1: case cannot be scored, "
          f"no candidates written [review/{subj}_qc.json]")
    sys.exit(3)
_cmp = f"{base}/review/confidence_model.json"; CONF_MODEL = None
if os.path.exists(_cmp):
    try: CONF_MODEL = css_confidence.load(_cmp)
    except Exception as e: print(f"{subj}: confidence model ignored ({e})")
CONF_ROLE = "" if CONF_MODEL is None else ("development" if subj in [str(s) for s in CONF_MODEL.get("studies", [])] else "evaluation")
CONF_CUT_OK = CONF_MODEL is not None and (CONF_MODEL.get("cut_method") == "lopo_min" or CONF_ALLOW_OPTIMISTIC)
if CONF and CONF_MODEL is not None and not CONF_CUT_OK:
    print(f"{subj}: low-confidence exclusion NOT applied - the model's cut ({CONF_MODEL.get('cut_pct')} %, method {CONF_MODEL.get('cut_method', 'not recorded')}) was not set "
          f"from leave-one-patient-out predictions. Refit with fit_confidence.py (default cut) or set CSS_CONF_ALLOW_OPTIMISTIC=1 to apply it knowingly.")
for r in rows:
    r["confidence_pct"] = np.nan; r["confidence_why"] = ""; r["conf_guard"] = 0
    if CONF_MODEL is not None:
        r["confidence_pct"] = float(css_confidence.confidence(CONF_MODEL, pd.DataFrame([r]))[0]); r["confidence_why"] = css_confidence.explain(CONF_MODEL, r)
for r in rows:
    rv, r["_excl"] = exclusion(r)
    r["qc_status"] = QC["status"]
    r["rule_version"] = rv or RULESET
    r["exclusion_confidence"] = ("low" if QC["status"] != "ok" else RULE_CONF[rv.split("@")[0]]) if rv else ""
    # v4.18 review tier (audit S3), RECORDED ONLY: 2 = the candidate's own flags point to a mimic. Nothing is hidden
    # and the order is unchanged (review_css.py --by-tier is opt-in). Case QC is not used: it applies to every
    # candidate of the case alike. Not validated - check the known lesions' tiers before ordering by it.
    why = [n for n, f in (("artifact zone", r["artifact_zone"]), ("vein-like", r["vein_like"]),
                          ("microbleed-like", r["cmb_like"]),
                          ("vein evidence > cSS evidence", r["vein_evidence"] > r["css_evidence"])) if f]
    r["review_tier"] = 2 if why else 1; r["tier_reason"] = "; ".join(why)
    # v5.1.3 review-priority tier (css_tiers.py): reading order only, nothing hidden or excluded by it
    r["review_priority_rank"], r["review_priority"], r["review_priority_reason"] = css_tiers.review_priority(r, QC["status"])
    if r.get("soft_gate_fail"):          # soft mode: read last, labelled
        r["review_priority_rank"] = max(int(r["review_priority_rank"]), 4)
        r["review_priority_reason"] = f"below a generation gate ({r['soft_gate_fail']}); " + str(r["review_priority_reason"] or "")
if CONF and CONF_GUARD:
    for _h in ("L", "R"):
        _side = [r for r in rows if r.get("hemi") == _h]
        if _side and not any(r["rule_version"] == RULESET for r in _side):
            _e30 = [r for r in _side if str(r["rule_version"]).startswith("E30")]
            if _e30:
                _k = max(_e30, key=lambda r: r["confidence_pct"])
                _k["_excl"] = ""; _k["rule_version"] = RULESET; _k["exclusion_confidence"] = ""; _k["conf_guard"] = 1
                print(f"{subj}: side guard - {_h} hemisphere would have no candidate left after the confidence rule; kept its highest-confidence object ({_k['confidence_pct']:.0f} %)")
excluded = [r for r in rows if r["_excl"]]
rows = [r for r in rows if not r["_excl"]]
os.makedirs(f"{base}/review", exist_ok=True)
xl = np.zeros(I.shape, np.int16)
if excluded:
    xdf = pd.DataFrame(excluded).sort_values("score", ascending=False).reset_index(drop=True)
    xdf.insert(0, "excl_id", np.arange(1, len(xdf) + 1))
    xr = np.zeros(lab.max() + 1, np.int16); xr[xdf["_lab"].values] = xdf["excl_id"].values; xl = xr[lab]
    xdf.rename(columns={"_excl": "reason"})[["excl_id", "reason"] + [c for c in cols if c not in ("cand_id", "accept")
                                                                      and c not in V50_COLS]
                                            + ["exclusion_confidence"] + V50_COLS] \
        .to_csv(f"{base}/review/{subj}_excluded.csv", index=False)
else:
    pd.DataFrame(columns=["excl_id", "reason"]).to_csv(f"{base}/review/{subj}_excluded.csv", index=False)
nib.save(nib.Nifti1Image(xl, swi.affine), f"{base}/review/{subj}_excluded.nii.gz")
# generation-gate drops (v4.14): not for review, but lets stress_test / check_known say why a lesion is missing
dl = np.zeros(I.shape, np.int16)
if dropped:
    ddf = pd.DataFrame(dropped)
    dr = np.zeros(lab.max() + 1, np.int16); dr[ddf["_lab"].values] = ddf["drop_id"].values; dl = dr[lab]
    ddf.drop(columns="_lab").to_csv(f"{base}/work/{subj}_dropped.csv", index=False)
else:
    pd.DataFrame(columns=["drop_id", "reason"]).to_csv(f"{base}/work/{subj}_dropped.csv", index=False)
nib.save(nib.Nifti1Image(dl, swi.affine), f"{base}/work/{subj}_dropped.nii.gz")
# ---- audit tables (always written): per-rule exclusion counts and, when calls exist, how many excluded objects were called cSS
_aud = {}
for r_ in excluded: _aud.setdefault(r_["rule_version"].split("@")[0], []).append(r_)
_aud_rows = []
_css_n = {}
_cp = f"{base}/review/{subj}_calls.csv"
if excluded and os.path.exists(_cp):
    _xd = pd.DataFrame(excluded).reset_index(drop=True); _xd["cand_id"] = np.arange(1, len(_xd) + 1)
    _m, _ = match_calls(_xd.rename(columns={"vox_i": "vox_i", "vox_j": "vox_j", "vox_k": "vox_k"}), pd.read_csv(_cp))
    if _m:
        for _k, _v in _m.items():
            if _v == "cSS": _css_n[_xd.loc[int(_k) - 1, "rule_version"].split("@")[0]] = _css_n.get(_xd.loc[int(_k) - 1, "rule_version"].split("@")[0], 0) + 1
for _rule, _lst in sorted(_aud.items()):
    _aud_rows.append(dict(rule=_rule, n_excluded=len(_lst), called_cSS_among_excluded=_css_n.get(_rule, "" if not os.path.exists(_cp) else 0),
                          calls_file="ID_calls.csv (fingerprint match)" if os.path.exists(_cp) else "none"))
pd.DataFrame(_aud_rows, columns=["rule", "n_excluded", "called_cSS_among_excluded", "calls_file"]).to_csv(f"{base}/review/{subj}_rule_audit.csv", index=False)
if SOFT_GATES:
    pd.DataFrame(soft_log, columns=["lab", "gate_id", "measured", "threshold"]).to_csv(f"{base}/work/{subj}_soft_gate.csv", index=False)
keep = np.zeros(I.shape, np.int16)
if rows:
    df = pd.DataFrame(rows); df["_soft"] = (df["soft_gate_fail"].fillna("") != "").astype(int)
    df = df.sort_values(["_soft", "score"], ascending=[True, False]).reset_index(drop=True).drop(columns="_soft")
    df.insert(0, "cand_id", np.arange(1, len(df) + 1))
    remap = np.zeros(lab.max() + 1, np.int16)
    remap[df["_lab"].values] = df["cand_id"].values
    keep = remap[lab]
    df["accept"] = ""
    df = df[cols]
else:
    df = pd.DataFrame(columns=cols)

os.makedirs(f"{base}/review", exist_ok=True)
df.to_csv(f"{base}/review/{subj}_candidates.csv", index=False)
nib.save(nib.Nifti1Image(keep, swi.affine), f"{base}/review/{subj}_candidates.nii.gz")
nib.save(nib.Nifti1Image(ich.astype(np.uint8), swi.affine), f"{base}/work/{subj}_ich_used.nii.gz")
# v5.1 fate invariant: every merged object ends in exactly ONE of dropped / excluded / shown, voxel for voxel
_n_obj = int(lab.max())
_fate_vox = (keep > 0).astype(np.int8) + (xl > 0) + (dl > 0)
_bad = []
if len(dropped) + len(excluded) + len(df) != _n_obj:
    _bad.append(f"{_n_obj} objects but {len(dropped)} dropped + {len(excluded)} excluded + {len(df)} shown")
if (_fate_vox > 1).any(): _bad.append(f"{int((_fate_vox > 1).sum())} voxels in more than one fate map")
if ((_fate_vox > 0) != (lab > 0)).any(): _bad.append(f"{int(((_fate_vox > 0) != (lab > 0)).sum())} object voxels without a fate")
del _fate_vox
if _bad:
    print(f"{subj}: FATE INVARIANT VIOLATED - " + "; ".join(_bad) + " (outputs written, but do not use them)")
    sys.exit(4)
FATES = dict(raw_components=int(n_raw), not_generated_unseeded=int(n_raw - n_seeded),
             pieces_before_merge=int(n_before_merge if n_before_merge is not None else _n_obj), objects=_n_obj,
             dropped_by_gate=pd.Series([d_["gate_id"] for d_ in dropped]).value_counts().to_dict() if dropped else {},
             excluded_by_rule=pd.Series([r_["rule_version"] for r_ in excluded]).value_counts().to_dict() if excluded else {},
             shown=int(len(df)), qc_blocked=0)
cnt = lambda c: int(df[c].astype(int).sum()) if len(df) else 0
print(f"{subj}: anatomy {'T1' if T1_ANAT else 'SWI-only (position rules relaxed)'}, "
      f"coverage {'includes skull base' if FULL_BOTTOM else 'cut off at the bottom (skull-base rules off)'}, "
      f"merge gap {MERGE_GAP_MM:.1f} mm")
print(f"{subj}: {n_raw} raw components -> {len(df)} candidates "
      f"[{len(excluded)} excluded: " + (", ".join(f"{v} {k.split(' (')[0].split(':')[0]}" for k, v in
      pd.Series([r['_excl'] for r in excluded]).value_counts().items()) if excluded else "none")
      + (f"; {n_before_merge - int(lab.max())} pieces joined, {n_chains} long chains kept apart"
         if n_before_merge is not None else "")
      + (f"; v5.3 ACTIVE: {n_joined_v53} more joined"
         f" (gap {V53_GAP_MM:g} mm, same region)" if V53 and n_before_merge is not None else "") + "] "
      f"({cnt('artifact_zone')} artifact zone, {cnt('midline_zone')} midline, {cnt('vein_like')} vein-like, "
      f"{cnt('near_ich_suggest')} near ICH [{ich_src}], {cnt('infratentorial')} infratentorial)  rank={RANK}"
      + ("  FLAIR used" if FL is not None else ""))
if fl_note: print(f"{subj}: {fl_note}")
print(f"{subj}: QC {QC['status']}" + (f" ({'; '.join(QC['reasons'])})" if QC["reasons"] else "")
      + f", label shift {QC['label_shift_mm']} mm, edge bias {QC['edge_bias_mm']} mm, scatter {QC['edge_scatter_mm']} mm, {len(dropped)} components below the generation gates"
      + " [review/" + subj + "_qc.json; reported only]")
_mc = pd.Series([r["mimic_class"] for r in rows + excluded]).value_counts().to_dict() if rows or excluded else {}
print(f"{subj}: mimic layer ({'ACTIVE' if USE_MIMIC else 'recorded only'}): "
      + (", ".join(f"{v} {k}" for k, v in _mc.items() if k != "none") or "no mimic evidence") + f"; {MIM.phase_note}")
print(f"{subj}: review tier (recorded only) 1: {sum(r['review_tier'] == 1 for r in rows)}, "
      f"2: {sum(r['review_tier'] == 2 for r in rows)}\n")
if len(df):
    print(df.head(15)[["cand_id", "hemi", "region", "volume_mm3", "darkness_z", "pial_dist_mm",
                       "tube_ratio", "surface_alignment", "tram_frac", "vein_tree_mm", "score",
                       "vox_i", "vox_j", "vox_k"]].to_string(index=False))
FROZEN_NAMES = ["MIN_MM3", "MIN_SLICES", "MIN_ELONG", "MIN_EXTENT_MM", "MERGE_GAP_MM", "MERGE_MAX_MM", "V53_GAP_MM", "V53_MAX_MM", "V53_OUT_MM",
                "E12_MM3", "E13_FRAC_V533", "E14_EDGE_MM", "E15_SKULL", "E16_FRAC", "E16_MM", "E17_FRAC", "E17_CTX", "E18_EDGE", "E19_DARK", "E19_SKULL",
                "E20_VOL", "E21_CTX", "E22_PLANE_MM", "E22_COS", "E22_EXT_MM", "E24_FRAC", "E24_LABELS", "E25_FRAC", "E25_REACH_MM", "ZONE2_R_MM", "ZONE2_FRAC", "SYLV_MM", "SYLV_FRAC", "STRUCT_BALL_CTX", "STRUCT_TUBE_CONT", "STRUCT_TUBE_COS", "MIN_SI_MM", "Z_LOW", "R_PCT_LOW"]
def frozen_rules():
    """thresholds in force for this run (the rule set is frozen pending held-out validation) -> manifest"""
    return {n: (list(globals()[n]) if isinstance(globals().get(n), (list, tuple)) else globals().get(n)) for n in FROZEN_NAMES if n in globals()}
def active_switches():
    """every experimental environment switch read by the detector, as set for this run"""
    return {k: os.environ.get(k, "") for k in ("CSS_V53", "CSS_USE_MIMIC", "CSS_MIXED_REVIEW", "CSS_QC_STRICT", "CSS_KEEP_ALL", "CSS_SATO_LEGACY",
                                              "CSS_RANK", "CSS_ALLOW_ORIENT", "CSS_SURFACE_ZONE", "CSS_SOFT_GATES", "CSS_3D_SEEDS", "CSS_E22_PIECES", "CSS_ZONE2", "CSS_ZONE2_FRAC", "CSS_SYLV_FRAC", "CSS_STRUCT", "CSS_CONF", "CSS_CONF_GUARD", "CSS_SLICE_GATE", "CSS_ALLOW_BAD_REG", "CSS_CONF_ALLOW_OPTIMISTIC")}
# v4.17 provenance: inputs (sha256), parameters, versions -> review/ID_manifest.json
_inputs = {k: p_ for k, p_ in (("swi", f"{base}/data/{subj}_swi.nii"), ("labels", f"{base}/work/{subj}_seg_swispace.nii.gz"),
                               ("t1_labels", _t1p), ("destrieux", f"{base}/work/{subj}_a2009s_swispace.nii.gz"),
                               ("flair", fl_p), ("phase", f"{base}/data/{subj}_phase.nii.gz"),
                               ("registration", f"{base}/work/{subj}_swi2t1.lta"), ("ich_drawn", ich_p))
           if os.path.exists(p_)}
update_manifest(base, subj, "detect", dict(
    pipeline_version=RULESET, run_at=pd.Timestamp.now().isoformat(timespec="seconds"), args=sys.argv[1:],
    parameters=dict(z_thr=z_thr, ridge_pct=r_pct, rim_mm=RIM_MM, rank=RANK, keep_all=KEEP_ALL,
                    slice_gate="legacy" if SLICE_GATE_LEGACY else f"mm (>= {MIN_SLICES} slices or >= {MIN_SI_MM} mm)", allow_bad_reg=ALLOW_BAD_REG,
                    confidence=dict(model=CONF_MODEL is not None, role=CONF_ROLE, cut_pct=None if CONF_MODEL is None else CONF_MODEL.get("cut_pct"),
                                    cut_method=None if CONF_MODEL is None else CONF_MODEL.get("cut_method", "not recorded"), exclusion_applied=bool(CONF and CONF_CUT_OK)),
                    use_mimic=USE_MIMIC, qc_strict=QC_STRICT, mixed_review=MIXED_REVIEW, phase=MIM.phase_note,
                    sato_sigmas_mm=list(SATO_SIGMAS_MM), sato_sigmas_px=[round(v, 2) for v in SATO_PX],
                    v53=V53, v53_out_mm=V53_OUT_MM, v53_gap_mm=V53_GAP_MM, v53_max_mm=V53_MAX_MM, v53_same_region_merge=True,
                    frozen_rules=frozen_rules(), switches=active_switches(), seeds3d=SEEDS3D_STATS),
    anatomy="T1" if T1_ANAT else "SWI-only", flair_used=FL is not None, qc_status=QC["status"],
    n_candidates=int(len(df)), n_excluded=len(excluded), n_dropped=len(dropped), fates=FATES,
    inputs={k: dict(path=p_, sha256=sha256(p_), mtime=os.path.getmtime(p_)) for k, p_ in _inputs.items()},
    environment=environment_record()))
