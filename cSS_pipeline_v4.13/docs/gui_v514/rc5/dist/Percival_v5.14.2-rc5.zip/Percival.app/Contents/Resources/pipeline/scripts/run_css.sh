#!/bin/zsh
# One patient, start to finish (up to review).
# usage: run_css.sh SUBJECT_ID [path/to/swi.nii(.gz)] [--nostrip] [--t1 T1.nii] [--flair FLAIR.nii] [--recon]
#                   [--phase PHASE.nii]
#   - with a SWI path: imports the scan; skull-strips it (with --t1: by the T1 brain labels after registration,
#     v5.2.5; without a T1: SynthStrip, which can need > 30 GB of memory) unless --nostrip
#     (use --nostrip only for scans that are already skull-stripped)
#   - SWI = the processed SWI (or magnitude) series, NOT the minIP and NOT the phase map
#   - --t1 / --flair / --recon: v4 anatomy from T1 (and FLAIR), see prep_anat.sh
#     (T1 labels are re-used on later runs; SynthSeg on the SWI is then skipped)
#   - --phase: the SWI PHASE series of the same acquisition (for reading only: the reviewer shows the
#     filtered phase, where calcium has the opposite sign to veins/blood products)
#   - set NOVIEW=1 to skip opening freeview (batch use)
set -e
S=$1; shift 2>/dev/null || true
SRC=""; STRIP=1; ANAT=(); PHASE=""
while [ $# -gt 0 ]; do
  case "$1" in
    --nostrip) STRIP=0; shift;;
    --t1|--flair) ANAT+=("$1" "$2"); shift 2;;
    --recon) ANAT+=("$1"); shift;;
    --phase) PHASE=$2; shift 2;;
    -*) echo "run_css.sh: unknown option $1"; exit 1;;
    *) SRC=$1; shift;;
  esac
done
B=${CSS_BASE:-$HOME/css_project}; SC=$B/scripts
if [ -z "$S" ]; then
  echo "usage: run_css.sh SUBJECT_ID [swi.nii] [--nostrip] [--t1 T1.nii] [--flair FLAIR.nii] [--recon]"; exit 1
fi
mkdir -p $B/data $B/synthseg $B/work $B/review
# v5.2.5: with a T1 the SWI is NOT skull-stripped with SynthStrip (it peaked at 64 GB on a 2 mm SWI and froze the
# user's 36 GB Mac): it is imported whole-head, registered as it is, and masked with the T1 brain labels after
# prep_anat.sh (swi_mask_from_t1.py). CSS_SWI_SKULLSTRIP=synthstrip restores the old SynthStrip route.
HAS_T1=0; for a_ in "${ANAT[@]}"; do [ "$a_" = "--t1" ] && HAS_T1=1; done
MASK_T1=0
if [ -n "$SRC" ] && [ $STRIP -eq 1 ] && [ $HAS_T1 -eq 1 ] && [ "${CSS_SWI_SKULLSTRIP:-t1}" != synthstrip ]; then MASK_T1=1; fi
if [ -n "$SRC" ] && [ $MASK_T1 -eq 1 ]; then
  echo "[0/4] importing (whole head; skull-stripped with the T1 brain labels after registration) $SRC"
  mri_convert "$SRC" $B/work/${S}_raw.nii.gz > /dev/null || { echo "ERROR: mri_convert could not read $SRC"; exit 1; }
  mri_convert $B/work/${S}_raw.nii.gz $B/data/${S}_swi.nii > /dev/null || { echo "ERROR: mri_convert failed on the SWI"; exit 1; }
elif [ -n "$SRC" ]; then
  if [ $STRIP -eq 1 ]; then
    echo "[0/4] importing + skull-stripping (SynthStrip, CSF kept) $SRC"
    mri_convert "$SRC" $B/work/${S}_raw.nii.gz > /dev/null || { echo "ERROR: mri_convert could not read $SRC"; exit 1; }
    # v4.18.3: errors were silent under set -e (LEMON P203 stopped here with no message); keep SynthStrip's output
    mri_synthstrip -i $B/work/${S}_raw.nii.gz -o $B/data/${S}_swi.nii -t ${CSS_THREADS:-4} \
      -m $B/work/${S}_brainmask.nii.gz > $B/work/${S}_synthstrip.log 2>&1 \
      || { echo "ERROR: mri_synthstrip failed on the SWI (exit $?) - last lines of $B/work/${S}_synthstrip.log:"; tail -5 $B/work/${S}_synthstrip.log; exit 1; }
  else
    echo "[0/4] importing (no skull-strip) $SRC"
    mri_convert "$SRC" $B/data/${S}_swi.nii > /dev/null
  fi
fi
if [ ! -f $B/data/${S}_swi.nii ]; then
  echo "ERROR: $B/data/${S}_swi.nii not found - give the scan path as 2nd argument"; exit 1
fi
if [ -n "$PHASE" ]; then
  echo "[0a] importing SWI phase (for the reviewer)"
  mri_convert "$PHASE" $B/data/${S}_phase.nii.gz > /dev/null
fi
if [ ${#ANAT[@]} -gt 0 ]; then
  echo "[0b] T1/FLAIR anatomy -> SWI grid"
  CSS_SWI_HEAD=$MASK_T1 zsh $SC/prep_anat.sh $S "${ANAT[@]}" || { echo "ERROR: prep_anat.sh failed - stopping (old labels would be used)"; exit 1; }
  if [ $MASK_T1 -eq 1 ]; then
    echo "[0c] skull-stripping the SWI with the T1 brain labels (no SynthStrip)"
    python $SC/swi_mask_from_t1.py $S || { echo "ERROR: swi_mask_from_t1.py failed - the SWI is still whole-head; stopping"; exit 1; }
  fi
fi
T1SEG=$B/work/${S}_t1seg_swispace.nii.gz
echo "[1/4] segmentation"
if [ -f $T1SEG ] && [ ! $B/data/${S}_swi.nii -nt $T1SEG ]; then
  echo "      using T1-derived labels ($T1SEG)"
# re-run when missing OR when the SWI was re-imported after the last segmentation (v4 fix:
# v3 silently reused a stale segmentation for a different scan with the same ID)
elif [ ! -f $B/synthseg/${S}_seg.nii.gz ] || [ $B/data/${S}_swi.nii -nt $B/synthseg/${S}_seg.nii.gz ]; then
  echo "      SynthSeg on the SWI (no T1 labels - consider --t1 for better anatomy)"
  mri_synthseg --i $B/data/${S}_swi.nii --o $B/synthseg/${S}_seg.nii.gz \
    --parc --robust --threads ${CSS_THREADS:-8} > /dev/null
else
  echo "      SynthSeg on the SWI (already done, skipping)"
fi
echo "[2/4] aligning segmentation to SWI"
python $SC/align_seg.py $S
echo "[3/4] detecting cSS candidates"
python $SC/detect_css.py $S -2.5 85 3 || { rc=$?
  [ $rc -eq 3 ] && echo "== $S: case cannot be scored (QC insufficient_quality, CSS_QC_STRICT=1) - see review/${S}_qc.json"
  exit $rc; }
# v4.19: pial-surface features (incl. curve-vs-patch width) whenever recon-all surfaces exist; recorded only,
# and a failure here (e.g. the surface/label registration check) never stops the run
SD=${CSS_SUBJECTS_DIR:-$B/subjects}
if [ -f $SD/$S/surf/lh.pial ] && [ -f $SD/$S/mri/orig.mgz ] && [ -f $B/work/${S}_swi2t1.lta ]; then
  echo "[3b] pial-surface features (recon-all surfaces; recorded only)"
  python $SC/surface_features.py $S || echo "      WARNING: surface_features.py failed - detection results are unaffected"
fi
# v5.0: trained ranking model, only when one exists AND the study is in the dev split (labels/study_meta.csv).
# Test-split studies are ranked by hand with the frozen model; studies without a split are not ranked.
if [ -f $B/review/ranker_model.json ]; then
  SPLIT=$(python -c "import pandas as pd,sys; m=pd.read_csv(sys.argv[1],dtype=str); m=m[m.study_id==sys.argv[2]]; print(m.split.iloc[0] if len(m) else '')" \
          $B/labels/study_meta.csv $S 2>/dev/null || true)
  if [ "$SPLIT" = "dev" ]; then
    echo "[3c] trained ranking model (rank_candidates.py; dev split)"
    python $SC/rank_candidates.py $S || echo "      WARNING: rank_candidates.py did not rank $S - the score_v4 order stands"
  else
    echo "[3c] ranking model not applied: $S split is '${SPLIT:-unassigned}' (only dev studies are ranked automatically)"
  fi
fi
if [ -z "$NOVIEW" ]; then
  echo "[4/4] opening viewer"
  freeview -v $B/data/${S}_swi.nii \
    $B/review/${S}_candidates.nii.gz:colormap=lut:opacity=0.6 > /dev/null 2>&1 &
fi
echo ""
echo "NEXT: python $SC/review_css.py $S          (interactive review of ALL candidates + score)"
echo "      or: python $SC/export_review.py $S 40 | pbcopy    (paste into the workbook)"
